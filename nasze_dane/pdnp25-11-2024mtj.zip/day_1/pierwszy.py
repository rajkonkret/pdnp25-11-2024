# komentarz
# PEP8 - zasada formatowania kodu

import sys

print()  # wypisz/wydrukuj - pusta linia
print(39)

print(sys.int_info)


