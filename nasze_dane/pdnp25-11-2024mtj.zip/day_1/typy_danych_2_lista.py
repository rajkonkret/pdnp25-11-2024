lista=[]
print(lista)
print(type(lista))