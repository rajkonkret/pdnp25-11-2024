import sys
wiek = 47
rok = 2024
temp = 36.6

print(temp)
print(type(temp))

print(wiek + rok)
print(wiek - rok)
print(wiek * rok)
print(wiek / rok)
print(rok // wiek)
print(rok % wiek)
print(wiek ** rok)
print(len(str(wiek ** rok)))

print(1/3)

print(54-5*43 + 8/2 +8/2)
print(54-5*43 + (8/2 +8)/2)

print(0.2 + 0.8)
print(0.22 + 0.7)
print(sys.float_info)

print(f"Sprawdzenie zmiennej {temp } {wiek}")

print(f"""
{wiek}
    {temp}""")

czy_znasz_pythona = True
print(czy_znasz_pythona)
print(bool(1))