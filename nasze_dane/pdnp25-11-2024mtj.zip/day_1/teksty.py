tekst = "Witaj Świecie"

print(tekst)
print(type(tekst))

tekst.upper()
print(tekst.upper())

print(tekst)
tekst_upper=tekst.upper()
print(tekst_upper)

print(tekst.lower())

print(tekst.count("i"))
print(tekst.count("j",0,4))


tekst_zamiana ="witaj dobry świecie"

print(tekst_zamiana.replace("dobry",""))

print(tekst.removeprefix("Witaj"))
print(tekst.removeprefix("Witaj").strip())
print(tekst.removesuffix("Świecie"))
print(tekst.removesuffix("Świecie").strip())