tekst = "Witaj Świecie"


encode_s = tekst.encode('utf-8')
print(encode_s)
print(type(encode_s))

print(encode_s.decode('utf-8'))

imie = "Jurek"

tekst_format = (f"Mam na imie {imie} i lubie pythona")

print(tekst_format)

tekst_format = (f"\tMam na imie {imie}\n i lubie pythona\b")

print(tekst_format)

starszy = "Witaj %s!"
print(starszy % imie)

print("Witaj3 {}".format(imie))

print("Witaj", imie)


user = "Tomek"
wiek = 39
wersja = 3.90001
print(type(wersja))
liczba = 5678907654321

print("Witaj %s, masz teraz %d lat" % (user, wiek))

print("Witaj %(user)s Lubię Cię  %(user)s" %{"user":user})

print("Witaj {}, masz teraz {} lat.".format(user,wiek))
print(f"witaj {user}, masz teraz {wiek} lat")

print("używam wersji pythona %i" % 3)
print("używam wersji pythona %f" % 3)
print("używam wersji pythona %.2f" % 3.9)
print("używam wersji pythona %.1f" % 3.9)
print("używam wersji pythona %.0f" % 3.9)
print("używam wersji pythona %.f" % 3)


print(f"uzywamy wersji pythona {wersja}")
print(f"uzywamy wersji pythona {wersja:.1f}")
print(f"uzywamy wersji pythona {wersja:.2f}")
print(f"uzywamy wersji pythona {wersja:.0f}")
# print(f"uzywamy wersji pythona {wersja:.f}")


print(f"{user:>10}")
print(f"{user:<15}")
print(f"{user:^20}")

print(liczba)

print(f"Nasza duża liczba {liczba:,}")
print(f"Nasza duża liczba {liczba:_}")
print(f"Nasza duża liczba {liczba:_}".replace("_",","))
print(f"Nasza duża liczba {liczba:_}".replace("_"," "))

liczba_2=150_000_000_000
print(liczba_2)
print(type(liczba_2))