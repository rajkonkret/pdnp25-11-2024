tekst = "Witaj Świecie"
print(tekst)
print(type(tekst))
# Witaj Świecie
# <class 'str'>

# wszystko jest obiektem
# """ Return a copy of the string converted to uppercase. """
tekst.upper()  # nie zmienia oryginalnego
print(tekst.upper())  # WITAJ śWIECIE
print(tekst)  # Witaj Świecie
tekst_upper = tekst.upper()
print(tekst_upper)  # WITAJ ŚWIECIE

# zamienić na male litery
print(tekst.lower())  # witaj świecie
teskt_lower = tekst.lower()


# Witaj Świecie
# 01234567891112...

print(tekst.count("i"))  # 3 wystepuje 3 razy
# start 0, stop 4 niełączacie!

tekst_zamiana = "Witaj dobry świecie"
print(tekst_zamiana.replace("dobry", ""))

# strip() - usunie białe znaki, spacje z początku i końca tekstu
print(tekst.removeprefix("Witaj"))  # " Świecie"
print(tekst.removeprefix("Witaj").strip())  # "Świeci"

print(tekst[4])  # indeks numer 4, j

encode_s = tekst.encode('utf-8')
print(encode_s)  #b'Witaj \xc5\x9awiecie' - typ bajtowy
print(type(encode_s))  # <class 'bytes'>
# \xc5\x9, \x liczba w systemie szesnastkowym -> \xc5 - 197
print(encode_s.decode('utf-8'))  # Witaj Świecie

imie = "Magda"
# f - fstring - tekst sformatowany
tekst_format = "Mam na imię {imie} i lubię pythona"
print(tekst_format)
tekst_format = f"\tMam na imię {imie}\n i lubię pythona.\b"
print(tekst_format)
# "	Mam na imię Magda
#  i lubię pythona"
# \t tabulator
# \n nowa linia
# \b backspace


print("""
test
    wielolinijkowy
    bbbbbb
    daaaaaa""")
#     wielolinijkowy
#     bbbbbb
#   daaaaaa
# ctrl / - komentarz zaznaczonego formatu



