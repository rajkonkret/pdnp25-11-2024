user = "Tomek"  # str
wiek = 39  # int
wersja = 3.900001   # <class 'float'>
print(type(wersja))  # <class 'float'>, liczby zmiennoprzcinkowe
liczba = 5678907654321  # int

print("Witaj %s, masz teraz %d lat" % (user, wiek))  # Witaj Tomek, masz teraz 39 lat
# %d: formatowanie liczb całkowitych
# %f: formatowanie liczp zmiennoprzecinkowych
# %s - łańcuch znaków (string)

# sprawdza typy
# print("Witaj %d, masz teraz %s lat" % (user, wiek))
# Traceback (most recent call last): ....

print("Wiaj %(user)s, Lubię Cię %(user)s" % {"user": user})
# Wiaj Tomek, Lubię Cię Tomek

print(liczba)  # 5678907654321
print(f"Nasza duża liczba {liczba:,}")  # Nasza duża liczba 5,678,907,654,321
print(f"Nasza duża liczba {liczba:_}")  # Nasza duża liczba 5_678_907_654_321
print(f"Nasza duża liczba {liczba:_}".replace("_", "."))  # Nasza duża liczba 5.678.907.654.321
print(f"Nasza duża liczba {liczba:_}".replace("_"," "))  # Nasza duża liczba 5 678 907 654 321

# liczba_2=15000000000
liczba_2 = 150_000_000_000
print(liczba_2)
print(type(liczba_2))
# 150000000000
# <class 'int'>