# warunki - instrukcje warunkowe
# instrukcje sterowania przepływem programu
# sterowana warunkiem if

# odp = True
# print(bool(odp))
# if odp:
#     # obowiązkowe 4 spacje
#     # wykona się, gdy warunek spełniony
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
#     print("Brawo")
# print("Dalsza częsc programu") # niezalezna instrukcja od if

odp = "Radek"
print(bool(odp)) # True
if odp:
    print("niepusty") # niepusty
if odp == "Tomek":
    print('To jest Tomek')
else:
    print('To nie jest Tomek')

# podatek = 0
# zarobki = int(input("podaj zarobki"))
# if zarobki < 10_000:
#     podatek = 0
# elif zarobki < 30_000:
#     podatek = 0.2
# elif zarobki < 100_000:
#     podatek = 0.4
# else:
#     podatek = 0.9
# print("podatek wynosi", podatek * zarobki)


# napisać aplikacje test
# zadać pytanie
# pbrać odpowiedź od użytkownika
# wypisac wynik

odp = input("Podaj rok Bitwy pod Grunwaldem")
if odp == '1410':
    print("poprawnie")
else:
    print("Musisz uczyć się dalej")