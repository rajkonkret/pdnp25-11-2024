# krotka, tuple - nie można modyfikować, kolekcja tylko do odczytu
# kolekcja niemutowalna
# pozwala lepiej zarządzać pamięcią
# krotka jednoelementowa - stała - zmienna

tupla = "Radek"
print(type(tupla)) # <class 'str'>

tupla1 = "Radek"
print(type(tupla1)) # <class 'str'>

tupla2 = "Radek",
print(type(tupla2)) # <class 'tuple'>

tupla3 = ("Radek",) # PEP8 zaleca żeby używać () w tuplach jednoelementowych
print(type(tupla3)) # <class 'tuple'>

tupla_liczby = 43, 55, 22.34, 11, 200
print(tupla_liczby)
print(type(tupla_liczby)) # tupla niemutowalna

tupla_imiona = "Julia", "Zenek","Marian","Stefan", "Zygmunt", "Gienia"
print(tupla_imiona) # ('Julia', 'Zenek', 'Marian', 'Stefan', 'Zygmunt', 'Gienia')
print(type(tupla_imiona)) # <class 'tuple'>

print(tupla_imiona.index("Gienia")) # indeks - 5
print(tupla_imiona.count("Gienia")) # występuje 1X
print(len(tupla_imiona)) # długość 6

# sortowanie zwróci nowa listę, ale nie zmieni krotki
print(sorted(tupla_imiona)) # ['Gienia', 'Julia', 'Marian', 'Stefan', 'Zenek', 'Zygmunt']
print(tupla_imiona) # ('Julia', 'Zenek', 'Marian', 'Stefan', 'Zygmunt', 'Gienia')

# rozpakowanie krotki
tup = 1, 2
a, b = 1, 2
print(a, b) # 1 2

a, b = tup
print(a, b)  # 1 2
# a, b = tupla_imiona # ValueError: too many values to unpack (expected 2)
a, *b = tupla_imiona # pierwszy element do a reszta do drugiego
print(a, b) # 1 2
name1, *name2, name3 = tupla_imiona
print(name1, name2, name3) # Julia ['Zenek', 'Marian', 'Stefan', 'Zygmunt'] Gienia

# możemy krotgkę zamienić na listę
lista = list(tupla_liczby)
print(lista)
# sprawdzamy, czy dany element wystepuje w liście
print(200 in lista) # True










