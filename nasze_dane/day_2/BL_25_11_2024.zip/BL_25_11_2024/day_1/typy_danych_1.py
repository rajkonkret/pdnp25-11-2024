wiek = 42
rok=2024
temp=36,6
print(wiek+rok)
print(wiek-rok)
print(wiek*rok)
print(wiek/rok)

print(rok//wiek)
print(rok % wiek)# modulo, reszta z dzielenia
print(10 % 3)

print(54-5*43+8/2+8/2)
print(54-5*43+(8/2+8)/2)


