lista=[]
print(lista)
print(type(lista))
pusta_lista=list()
print(pusta_lista)
print(type(pusta_lista))

#dodawanie elementów do listy

lista.append("Radek")
lista.append("Grzegorz")
lista.append("Maciek")
lista.append("Marek")

#ctrl+alt+l formaltowanie zgodnie z
print(lista)

print(lista[0])
print(lista[2])
print(lista[3])

print(len(lista))#dlugosc listy
print(lista[3])


#fragment listy (slicowanie)
print(lista[0:3]) #start stop
print(lista[:3])
print(lista[2:3])
print(lista[:])

lista_15 = list(range(15))
print(lista_15)
print(lista_15[0:15:2])
print(list(range(0, 15, 2)))

print(lista)
lista[3]="Radek"#zamiana elenetu w liscie
print(lista)

lista.insert(1,"Marek") #dodaje do listu
print(lista)

print(lista.index("Grzegorz"))#numer indeksu

lista.append("Zenek")
print(lista)

print(lista.remove("Zenek"))
print(lista)

print(lista.pop(4))#usuwa i pokazuje co usnąłem


lista_litery=["b","a","w","z"]
lista_litery.sort()
print(lista_litery)

lista_litery.sort(reverse=True)
print(lista_litery)
print(lista_litery[::-1])


tekst="Pyt hon."
lista1=list(tekst)
print(lista1)

lista2=[tekst]
print(lista2)
krotka=tuple(lista_litery)

print(krotka)
print(type(krotka))