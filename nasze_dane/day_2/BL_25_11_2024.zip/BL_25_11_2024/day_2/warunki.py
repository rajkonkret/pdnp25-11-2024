odp=True
print(bool(odp))
if odp:
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
print("Dalsza czsc programu")

if odp=="Tomek":
    print('To  jest Tomek')
else:
    print('To nie jest tonek')

podatek=0
zarobki=int(input("Podaj zarobki"))
if zarobki<10000:
    podatek=0
elif zarobki<100000:
    podatek=0.4
elif zarobki<30000:
    podatek=0.2
else:
    podatek=0.9
print("Podatek wynosi",podatek*zarobki)