tupla="Radek"
print(type(tupla))

tupla1=("Radek")
print(type(tupla1))

tupla2="Radek",
print(type(tupla2))


tupla3=("Radek",)
print(type(tupla3))

tupla_liczby=43,55,22.3,11,200
print(type(tupla_liczby))
print(tupla_liczby)

#tupla jest niemutowalna nic nie zmienisz

tupla_imiona="Radek", "Tomek","Zenek","Marcin","Jacek","Ania","Zosia"
print(tupla_imiona)
print(type(tupla_imiona))

print(tupla_imiona.index("Radek"))
print(tupla_imiona.count("Ania"))

print(len(tupla_imiona))

print(sorted(tupla_imiona)) #zwraca nową listę nie zmienia krotki
print((tupla_imiona))

tup = 1,2
a,b=1,2
print(a,b)

a,b= tup
print(a,b)
a, *b =tupla_imiona
print(a,b)

*name1,name2,name3=tupla_imiona
print(name1,name2,name3)

name1,*name2,name3=tupla_imiona
print(name1,name2,name3)

name1,name2,*name3=tupla_imiona
print(name1,name2,name3)