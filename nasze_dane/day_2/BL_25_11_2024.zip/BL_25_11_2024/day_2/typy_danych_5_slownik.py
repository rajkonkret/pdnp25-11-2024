
dictionary={}
dictionary_1={}
print(dictionary_1)
print(type(dictionary_1))

dictionary ['imie']="Radek"
print(dictionary)

dictionary ['wiek']="45"
print(dictionary)
dictionary['imie']="Tomek"
print (dictionary)

print(dictionary.keys()) #klucze
print(dictionary.values()) #wartosći
print(dictionary.items())#pary

print(dictionary['imie'])
print(dictionary['wiek'])

print(dictionary.get("Imie"))#none gdy nie ma klucza


dictionary.update({"date":"12-12-2024"})
print(dictionary)
dict_small = {"x":2}
dict_small.update([('y',3),('z',7)])
print(dict_small)

#tekst=input("Podaj imie")
#print(tekst)


#l1=int(input("Podaj lczbę:"))
#l2=input("Podaj lczbę:")2


#print( l1+float(l2))


pol_ang={"kot" : "cat", "pies":"dog", "dach":"roof"}
print("MAmay takie slowa",pol_ang.keys())
odp=input("podaj slowko")
#print(pol_ang[odp.lower()])
#print(pol_ang[odp.casefold()])
print(f'Tlumaczenie {odp}:{pol_ang.get(odp.casefold().strip(),"Nie ma")}')
