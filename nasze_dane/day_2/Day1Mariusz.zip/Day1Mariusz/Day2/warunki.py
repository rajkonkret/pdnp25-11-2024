# warunki - instrukcje warunkowe
# instrukcje sterowania przepływem programu
# if - sterowana warunkiem

#odp = True
#print(bool(odp))
#odp = False
#if odp:
    #obowiązkowe 4 spacje
    #wykona się gdy warunek spełniony
    #   print("Brawo")
    #  print("Brawo")
    # print("Brawo")
    #print("Brawo")
    #print("Brawo")
    #print("Brawo")
    #print("Brawo")

#print("Dalsza część progrmu") #niezależna od if instrukcja
#odp = Radek
#print(bool(odp))
#print(odp=="Radek"
# else w przeciwnym wypadku

#podatek =0
#zarobki = int(input("Podaj zarobki"))
#if zarobki <10_000:
#    podatek = 0
#elif zarobki < 30_000:
#    podatek = 0.2
#elif zarobki<100_000: #kolejny if
#    podatek = 0.4

#else:
 #   podatek = 0.9

#print("Podatek wynosi", podatek * zarobki)
# podatej 0.2 dla dochodów od 10000 do 30000

# napisać aplikację test
#zadać pytanie
# pobrać odpowiedź od użytkownika
#wypisać wynik

punkty = 0
odp = input('Podaj rok bitwy pod Grunwaldem')   #string
if odp.strip() == "1410":
    print ("Zdałeś")
    punkty += 1 #punkty = punkty + 1
else:
    print("Musisz uczyć się dalej")
print(f"Zdobyłeś { punkty } punkty.")

