# słownik - dane typu para klucz - wartość
# {"user" : "Radek", "wiek" : 78}
# {"klucz" : "wartość"}
# {"firstName":"John","lastName":"Doe:}
# klucze nie mogą się powtarzać

# pusty słownik
dictionary = dict()
print(dictionary)  # {}

dictionary_1 = {}  # {}
print(type(dictionary_1))  # <class 'dict'>

# dodawanie elementów do słownika
dictionary['imię'] = "Radek"
print(dictionary)  # {'imię': 'Radek'}

dictionary["wiek"] = "45"
print(dictionary)  # {'imię': 'Radek', 'wiek': '45'}

# nadpisanie elementu
dictionary['imie'] = "Tomek"
print(dictionary)

print(dictionary.keys())
print(dictionary.values())
print(dictionary.items())

# wypisanie elementu ze słownika
print(dictionary["imie"])  # Tomek
print(dictionary["wiek"])  # 45

# print(dictionary["Imie"])
print(dictionary.get("Imie"))  # None gdy nie ma klucza
print(dictionary.get("Imie", "default"))  # default gdy nie ma klucza

dictionary.update({"date": "12-12-2024"})
print(dictionary)  # {'imię': 'Radek', 'wiek': '45', 'imie': 'Tomek', 'date': '12-12-2024'}

dict_small = {"x": 2}
dict_small.update([("y", 3), ("z", 7)])
print(dict_small)  # {'x': 2, 'y': 3, 'z': 7}

# input() - pobiera dane od użytkownika
# tekst = input("Podaj imię") #input zwraca <class 'str'>
# print(tekst)

# napisać aplikację kalkulator
# pobrać dwie liczby - 2 x input
# wypisać wynik dodawanie -> print

#a = int(input("Podaj pierwszą liczbę"))
#print(a)
#b = int(input("Podaj drugą liczbę"))
#print(b)
#print("suma", a + b)

# napisać aplikację pol-ang
#słownik ze słowkami i tłumaczeniami
#wyświetlić tłumaczenie -> wartośc klucza

slownik = {"one": "jeden", "two":"dwa"}
print("Mamy takie słówka", slownik.keys())
angielskie = input("Podaj angielskie słowo:")
print(slownik[angielskie])
