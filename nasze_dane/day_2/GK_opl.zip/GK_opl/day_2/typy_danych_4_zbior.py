# zbiór (set) -   przechowuje unikalne wartości
# nie zachowuje kolejności przy dodawaniu elementów
# nie ma indeksu

lista=[44,55,66,777,33,22,11,33,11]
zbior= set(lista)
print(type(zbior))  #<class 'set'>
print(zbior)  # {33, 66, 777, 11, 44, 22, 55}
# zbiór wartości prezentuje w klamerakch

# utworzenie pustego zbioru
zb2=set()   # utwoerzenie poprzez slówo kluczowe set, liste można było dać tylko nawiasy kwadratowe
print(zb2)  #set()

# dodanie elementu do zbioru
zbior.add(33)
zbior.add(33)
zbior.add(33)
zbior.add(18)
zbior.add(18)
zbior.add(568)
print (zbior)  #{33, 66, 777, 11, 44, 18, 22, 55, 568}

# usunięcie lementu ze zbioru
zbior.remove(55)
print(zbior)  #{33, 66, 777, 11, 44, 18, 22, 568}

#pop()  na liście usuwał i wyswietlał po indeksie
print(zbior.pop())  #33 , usuwa pierwszy element, dla listy pop() usuwał ostatni element jesłi podany bez indeksu

zbior_copy = zbior.copy()
print(zbior)  #{66, 777, 11, 44, 18, 22, 568}
print(zbior_copy)   #{66, 18, 22, 568, 777, 11, 44}   nawet kopia się równi :)
print(id(zbior))
print(id(zbior_copy))
# 2065775051936
# 2065775335616



zbior_2 ={667,11,44,18,52,62,999,999,12.34}
print(type(zbior_2)) #<class 'set'>
print(zbior_2)  # {999, 11, 44, 12.34, 18, 52, 667, 62}
print(zbior) #{66, 777, 11, 44, 18, 22, 568}

# suma zbiorów  - nowy zbior automatycznie usunął  duplikaty
print(zbior | zbior_2) #{66, 999, 777, 11, 44, 12.34, 18, 52, 22, 568, 667, 62}
print(zbior.union(zbior_2)) #{66, 999, 777, 11, 44, 12.34, 18, 52, 22, 568, 667, 62}  inna notyfikacja  to samo co wyżej

# cześć wspólna
print(zbior & zbior_2) #{18, 11, 44}
print(zbior.intersection(zbior_2)) #{18, 11, 44}


# różnica
# odczywiście kolejność jest ważna - 5-2 to różne od 2-5
print(zbior - zbior_2)  #{568, 777, 66, 22}
print(zbior.difference(zbior_2))   #{568, 777, 66, 22}
print(zbior_2.difference(zbior))  #{999, 12.34, 52, 667, 62}


# modyfikuje zbiór bazowy
zbior.update((zbior_2))  # uzupełnił zbior o elementy zbioru_2
print(zbior)  #{66, 999, 777, 11, 44, 12.34, 18, 52, 22, 568, 667, 62}

# sprawdzeanie czy w zbiorze jest taka wartość

print(999 in zbior)  # True

print(sorted(zbior))  # zwraca posortowaną liste, nie zmienia zbioru, zbiór nie ma indeksu
# [11, 12.34, 18, 22, 44, 52, 62, 66, 568, 667, 777, 999]
print(zbior) #{66, 999, 777, 11, 44, 12.34, 18, 52, 22, 568, 667, 62}


