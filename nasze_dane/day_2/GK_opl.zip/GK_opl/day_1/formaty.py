user = "Jacek"   # str
wiek = 41 # int
wersja = 3.90001  # <class 'float'>

print(type(wersja))  # <class 'float'>   liczby zmiennoprzecinkowe

liczba = 567892234231  # int

print("Witaj %s, masz teraz %d lat" % (user, wiek))  # Witaj Jacek, masz teraz 41 lat

print("Witaj %s, masz teraz %d lat" % (user, wiek))

# %d - formatowanie liczb całkowitych
# %f - fromatowanie liczb zmiennoprzecinkowych
# %s - łańcuch znaków ( string)



print("Witaj")

print(f"używamy wersjipyhona{wersja}")        # używamy wersjipyhona3.90001
print(f"używamy wersjipyhona{wersja:.1f}")    # używamy wersjipyhona3.9
print(f"używamy wersjipyhona{wersja:.2f}")     #używamy wersjipyhona3.90
print(f"używamy wersjipyhona{wersja:.0f}")     #używamy wersjipyhona4
# print(f"używamy wersjipyhona{wersja.f}")      # bład

user="Tomek"

print(f"{user:>10}")    #  "    Tomek" - do prawej
print(f"{user:<15}")  # Tomek             " - do lewej
print(f"{user:^20}")    #        Tomek      "   wyśrodkowane razem 20 znaków


print (liczba)      # 567892234231
print(f"Nasza duża liczba{liczba:,}")   # Nasza duża liczba567,892,234,231
print(f"Nasza duża liczba{liczba:_}")   # Nasza duża liczba567_892_234_231
print(f"Nasza duża liczba{liczba:_}".replace("_","."))   # Nasza duża liczba567.892.234.231
print(f"Nasza duża liczba{liczba:_}".replace("_"," "))   # Nasza duża liczba567 892 234 231

# liczba_2=1500000000
liczba_2 = 150_000_000_000   #  bład gdy wcięcie na początk linii:  IndentationError: unexpected indent
print(liczba_2)
print(type(liczba_2))