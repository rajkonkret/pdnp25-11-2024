#warunki - instrukcje warunkowe
#instrukcje sterowania przepływem programu
from idlelib.debugger_r import CodeProxy

odp = True
print(bool(odp))
# odp = False
if odp:
    # obowiązkowe 4 spacje
    # wykona sie gdy warunek spełniony
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")

    print("Dalsza część programu)")

odp = "Radek"
print(bool(odp))
print(odp =="Radek")

if odp:
    print("Nie pusty string")

if odp== "Radek":
    print("Radek")

if odp =="Tomek":
    print('To jest Tomek')
else:
    print('To nie jest Tomek')

# podatek = 0
# zarobki = int(input("Podaj zarobki"))
# if zarobki < 10000:
#     podatek = 0
# elif zarobki <100000:
#     podatek = 0.4
# else:
#     podatek = 0.9

    # print("Podatek wynosi", podatek*zarobki)
punkty = 0
odp = input("Podaj rok Bitwy pod Grunwaldem")
if odp =='1410':
        print("Zdałeś")
        punkty +=1
else:
        print("Musisz uczyć się dalej")
        print("Zdobyłes punkty")