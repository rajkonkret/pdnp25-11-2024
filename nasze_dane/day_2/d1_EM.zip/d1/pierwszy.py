# komentarz
# PEP8 - zasady formatowania kodu
# ctrl alt l
import sys
print() # wypisz/wydrukuj

print("Nazywam się Emilia")
print("Nazywam się Emilia")
print("Nazywam się Emilia")
print("Nazywam się Emilia")
print("Nazywam się Emilia")

# print("Nazywam się Emilia")
# print("Nazywam się Emilia")
# print("Nazywam się Emilia")
# print("Nazywam się Emilia")
# print("Nazywam się Emilia")


print('Nazywam się Emilia')

print("Nazywam się 'Emilia'")
print(type("Emilia"))
print("39")
print(type("39"))
print(type(39))

print(39+39)
print("39"+"39")


# print("39"+39)

print(int("39")+39)
print(str(39)+"39")

print("Radek:" + str(39))

print(5*"4")
print(4*4)
print(160*"5")

liczba = 39
print(type(liczba))
print(liczba)

liczba = "Ewa"
print(liczba)
print(type(liczba))

name: str = "Ewa"
print(name)
print(type(name))

name= 90
print(name)

age = 38
print(age)
print(type(age))

print(sys.int_info)

