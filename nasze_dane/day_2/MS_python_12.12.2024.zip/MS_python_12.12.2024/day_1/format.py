user = "Tomek"  # str
wiek = 39  # int
wersja = 3.90001  # <class 'float'>

print(type(wersja))

liczba = 567890123456  # int

print("Witaj %s, masz teraz %d lat." % (user, wiek))

print(f"Witaj {user}, masz teraz {wiek} lat.")

print(liczba)

liczba_2 = 150_000_000_000
print(type(liczba_2))

print(liczba_2)