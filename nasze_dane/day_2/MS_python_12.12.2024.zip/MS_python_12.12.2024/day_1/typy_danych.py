import sys

wiek = 47
rok = 2024
temp = 36.6

print(wiek)
print(type(temp))

print(wiek + rok)
print(wiek - rok)
print(wiek * rok)
print(wiek / rok)

print(rok // wiek)
print(rok % wiek)

print(1/3)

print(sys.float_info)

print(bool(0))
print(bool("cos"))

a = 8
b = 6

print(f"Porównianie {a} > {b} = {a > b}")
print(f"Porównianie {a} < {b} = {a < b}")
print(f"Porównianie {a} >= {b} = {a >= b}")
print(f"Porównianie {a} <= {b} = {a <= b}")
print(f"Porównianie {a} == {b} = {a == b}")
print(f"Porównianie {a} != {b} = {a != b}")

print(a == b)
print(f"{a==b = }")