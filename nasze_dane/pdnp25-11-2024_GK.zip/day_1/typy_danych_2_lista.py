# kolekcje
# mogą przechowywać wiele elementów  róznego typu na raz - w jednej kolekcji mogą być i int i str i float
# LIsta - przechowuje dowolną ilość elementów óżnego rodzaju na raz
# zachowuje kolejność przy dodawaniu elementów - podstawowa cecha listy
# charakterystycznem elementem listy jest nawias kwadratowy

lista= []
print(lista)  # []
print(type(lista))  # <class 'list'>

pusta_lista = list()

print(pusta_lista)  # []
print(type(pusta_lista))  #<class 'list'>

