#komentarz
# PEP8  - zasady formatowania kodu
# ctrl alt l

print()  # wypisz/ wydrukuj - pusta linia

# print ("Nazywam się Greg")
# print ("Nazywam się Greg")
# print ("Nazywam się Greg")
print ("Nazywam się 'Greg'") # nazywam się 'Greg'

print(type("Radek"))
print("39")
print (39+39)

import sys

print(sys.int_info)
