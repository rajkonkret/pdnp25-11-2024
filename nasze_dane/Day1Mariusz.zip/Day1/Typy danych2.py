# kolekcje
# mogą przechowywać wiele elementów, różnego typu na raz
# Lista - przechowuje dowolną ilość elementów, różnego rodzaju na raz
# zachowuje kolejność przy dodawaniu elementów

#pusta lista
lista = []
print(lista)
print(type(lista))

pusta_lista = list()
print(type(pusta_lista))
