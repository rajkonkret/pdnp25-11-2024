# komentarz
# posdjsd
#
# print("No 'siema'")
# print(type("Rafał"))
# print(45)
# print(type(45))
# print(int("45")+45)
# print(str(45)+"45")
# # print("Rafal: " + str(45))
# liczba = 45
# print(type(liczba))
# print(liczba)
#
# liczba = "rafal"
# print(type(liczba))
# print(liczba)
#
# name: str = "Rafal"
# print(name)
# print(type(name))
#
# name = 45
# print(name)
import sys
print(sys.int_info)

