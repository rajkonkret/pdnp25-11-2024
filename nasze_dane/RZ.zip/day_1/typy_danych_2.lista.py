lista = []
print(lista)
pusta_lista = list()
print(pusta_lista)
