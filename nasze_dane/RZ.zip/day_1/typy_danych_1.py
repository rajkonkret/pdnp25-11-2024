import sys

wiek = 47
rok = 2024
temp = 36.6

# print(temp)
# # print(type(temp))
# print(wiek + rok)
# print(wiek - rok)
# print(wiek * rok)
# print(type(wiek / rok))

# print(rok // wiek)
# print(rok / wiek)
# print(rok % wiek)
# print(10 % 3)
# print(len(str(wiek ** rok)))

# print(54 - 5 * 43 + 8 / 2 + 8 / 2)
# print(54 - 5 * 43 + (8 / 2 + 8) / 2)
#
# print(0.2 + 0.8)
# print(0.2 + 0.7)
# print(0.1 + 0.2)
#
# print(1.23 * 2 ** 34)
# print(sys.float_info)
# print(f"Sprawdzenie zmiennej {temp} {wiek}")
# print(f"""
# {wiek}
#     {temp}""")

czy_znasz_pythona = True
print(czy_znasz_pythona)
print(type(czy_znasz_pythona))
print(int(czy_znasz_pythona))
print(bool(0))

print(bool(100))
print(bool(0))
print(bool(""))
print(bool("rafal"))

print(bool(None))

print(True and False)
print(True and True)

print(True or False)
print(True or True)
print(False or False)

print(not True)
print(not False)

a = 8
b = 6
print(f"Porównanie {a} > {b} = {a > b}")
print(f"Porównanie {a} < {b} = {a < b}")
print(f"Porównanie {a} <= {b} = {a <= b}")
print(f"Porównanie {a} >= {b} = {a >= b}")
print(f"Porównanie {a} == {b} = {a == b}")
print(f"Porównanie {a} != {b} = {a != b}")

print(f"{a==b = }")






