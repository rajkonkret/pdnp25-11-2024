# słownik -  dane typu para:  klucz-wartość
# {"user" : "Radek", "wiek" :78}
# {"klucz" : "wartość"}
# {"firstname":"John", "LastName":"Doe"}
# klucze nie mogą się powtarzać
# from nasze_dane.GK_opl.day_1.typy_danych_2_lista import liczby

# pusty słownik
dictionary = dict()
print(dictionary)  # {}

dictionary_1 = {}  # niepomylić ze zbiorem - tam ustawiamy SET()
print(dictionary_1)  # {}
print(type(dictionary_1))  # <class 'dict'>

# dodawanie elementów do słownika

dictionary['imie'] = "Grzegorz"
print(dictionary)  # {'imie': 'Grzegorz'}

dictionary['wiek'] = "50"
print(dictionary)  # {'imie': 'Grzegorz', 'wiek': '50'}

# nadpisanie elementu

dictionary['imie'] = "Tomek"
print(dictionary)  # {'imie': 'Tomek', 'wiek': '50'}

print(dictionary.keys())  # dict_keys(['imie', 'wiek'])   klucze
print(dictionary.values())  # dict_values(['Tomek', '50'])   wartości
print(dictionary.items())  # dict_items([('imie', 'Tomek'), ('wiek', '50')])    pary/elementy słownika  JSON

# wypisanie elementu ze sownika

print(dictionary['imie'])  # Tomek
print(dictionary['wiek'])  # 50

# print(dictionary("Imie"))  # KeyyError  brak klucza
print(dictionary.get("Imie"))  # None gdy nie ma klucza
print(dictionary.get("Imie", 'default'))  # Default, gdy nie ma klucza

dictionary.update({"date": "12-12-2024"})
print(dictionary)  # #{'imie': 'Tomek', 'wiek': '50', 'date': '12-12-2024'}

dict_small = {"x": 2}
dict_small.update([('y', 3), ("z", 7)])  # nadpisanie np tuplami, listą tupli
print(dict_small)  # {'x': 2, 'y': 3, 'z': 7}

# input() - pobiera dane od użytkownika
# tekst = input("Podaj imię: ")  # input zawsze zwraca string
# print(tekst)
# Podaj imię: Greg
# Greg

# print(type(tekst))

# napisać aplikację kalkulator
# pobrać dwie liczby -> 2x input
#


# # kalkulator
# l1 = int(input("Podaj pierwszy składnik:  "))
# l2 = int(input("Podaj drugi składnik:  "))
# # print(l1+l2)
# # suma = l1+l2
# print("wynik to ", l1 + l2)

# inny kalkulator
# a= int(input("Podaj pierwszą liczbę"))
# b= input("Podaj drugą liczbę")
# print(a+float(b))

# napisać aplikację pol-ang słownik
# słownik ze słowami i tłumaczeniami
# pobrać od użystkownika o co pyta -> input
# wyświetlić wartość klucza
#
# slownik = dict()
# # slownik['pol'] = "gwiazda"
# # slownik['ang'] = "star"
# slownik.update([("oko","eye"),("okno","window"),("drzwi","door")])
# # dict_small.update([('y', 3), ("z", 7)])
# print(slownik)

pol_ang = {"kot":"cat", "pies":"dog", "drzwi":"door"}
print("mamy takie słówka", pol_ang.keys())
odp = input("POdaj słówko do przetłumaczenia:  ")
# print(pol_ang[odp.lower()])

print(f'Tłumaczenie  {odp}:{pol_ang.get(odp.casefold().strip(), "nie ma ;)")}')
