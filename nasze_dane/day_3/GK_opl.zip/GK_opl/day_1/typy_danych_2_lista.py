# kolekcje
# mogą przechowywać wiele elementów  róznego typu na raz - w jednej kolekcji mogą być i int i str i float
# LIsta - przechowuje dowolną ilość elementów óżnego rodzaju na raz
# zachowuje kolejność przy dodawaniu elementów - podstawowa cecha listy
# charakterystycznem elementem listy jest nawias kwadratowy

lista= []
print(lista)  # []
print(type(lista))  # <class 'list'>

pusta_lista = list()

print(pusta_lista)  # []
print(type(pusta_lista))  #<class 'list'>

# dodawanie elementów do listy
lista.append("Radek")
lista.append("Grzegorz")
lista.append("Zenek")
lista.append("Dariusz")
lista.append("Zośka")
lista.append("Zuzia")
lista.append("Marzcin")


print(lista)
# lista wypisywana w nawiasach a stringi w apostrofach
# ['Radek', 'Grzegorz', 'Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']
#     0          1          2       3           4       5           6 - indeksy
#       -7          -6      -5      -4      -3          -2          -1

print(lista[0])
print(lista[2])
print(lista[4])


# ctrl alt l  - formatowanie zgodne z PEP8


print(len(lista))  #  len()   - długośc listy  7 elementów

#print(lista[7])   # INdexError:  list index out of range

print (lista[len(lista) -1])   # odp ->  Marzcin

print(lista[-1])
print(lista[-2])
print(lista[-3])
#Marzcin
#Zuzia
#Zośka

#  wyświetlanie fragmentu listy tzw slicowanie

# start - stop
print(lista[0:3])  # [start : stop],  ['Radek', 'Grzegorz', 'Zenek']  -> indeksy 0 1 2
print(lista[:3])  # [start : stop],  ['Radek', 'Grzegorz', 'Zenek']    -> 0 1 2
print(lista[2:])  # ['Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']  -> indeksy  2 3 4 5 6 7  cała lista
print(lista[2:5])  # indeksy 2 3 4   ['Zenek', 'Dariusz', 'Zośka']
print(lista[2:6])  # indeksy 2 3 4 5   ['Zenek', 'Dariusz', 'Zośka', 'Zuzia']

print(lista[2:10]) # ['Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']   cała lista
print(lista[10:20])  # pusta lista    []

print(lista[2:2])  # pusta lista    [] wyswietl od element 2 do  elementu 2 bez elementu 2
print(lista[2:3])  # jeden element o inx 2
print(lista[:]) # wyświetla całą listę  ['Radek', 'Grzegorz', 'Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']

print(lista[-2:0])  # [5:0]  -> []   indeksy nie zawijają się
print(lista[0:-2])  # [0:5]    ['Radek', 'Grzegorz', 'Zenek', 'Dariusz', 'Zośka'] wybierz wszystko bez 2 ostatnich
print(lista[-6:-2])  #['Grzegorz', 'Zenek', 'Dariusz', 'Zośka']
#  - cała lista to dla przypomnienia  -> ['Radek', 'Grzegorz', 'Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']  - cała lista

#  mechanizm pozwalajacy generować lista liczb z zakresu

lista_15 = list(range(15))  #  0 to 14   [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
print(lista_15)

print(lista_15[0:15:2]) # wyświetla co drugi element

print(list(range(0,15,2))) # generowanie co drugi element od 0 do 14 co drugi
#[0, 2, 4, 6, 8, 10, 12, 14]     - start, stop, krok

print(lista_15[-10])  # 5


# nadpisanie listy

print(lista)
lista[3]="Mikołaj"
print(lista)
# ['Radek', 'Grzegorz', 'Zenek', 'Dariusz', 'Zośka', 'Zuzia', 'Marzcin']
# ['Radek', 'Grzegorz', 'Zenek', 'Mikołaj', 'Zośka', 'Zuzia', 'Marzcin']

# dopisanie elementu do listy we wskazanym miejscu

lista.insert(1,"TOMEK")
print(lista)  # ['Radek', 'TOMEK', 'Grzegorz', 'Zenek', 'Mikołaj', 'Zośka', 'Zuzia', 'Marzcin']
# dodawanie elementu na końcu listy przez funkcję :  lista.append("Radek")

# sprawdzenie indeksu dla elementu
print(lista.index("Zenek")) # indeks numer 3

# usunięcie elementu z listy
lista.append("Zenek")
print(lista)
# ['Radek', 'TOMEK', 'Grzegorz', 'Zenek', 'Mikołaj', 'Zośka', 'Zuzia', 'Marzcin', 'Zenek']
# mammy dwóch Zenków

lista.remove("Zenek")   # remove() - usunięcie z listy w tym przypadku "ZEnek
# funkcja usuwa pierwsze wystąpienie elementu
print(lista)  # ['Radek', 'TOMEK', 'Grzegorz', 'Mikołaj', 'Zośka', 'Zuzia', 'Marzcin', 'Zenek']

# usunięcie z listy po indeksie i zwraca co usuneło
print(lista.pop(5))  # Zuzia   -  pop - usuwanie i pokazanie co usunąłem
#  ['Radek', 'TOMEK', 'Grzegorz', 'Mikołaj', 'Zośka', 'Marzcin', 'Zenek']
print(lista)

print(lista.pop(-2))   # usunięty "Marzcin"
print(lista.pop())   # usuwa ostatni elelment  tutaj "Zenek"
print(lista)    # print(lista)

a = 1
b = 3
print(a,b)   # 1  3
a=b   # do zmiennej a  przypisz wartość b
print(a,b)  #  3  3

b=7

print(f"{a=},{b=}")  #  wstrzykiwanie wartości  wypisze  a=3, b=7

lista_2 = lista
print(lista)
print(lista_2)
#lista.clear()  # czyszczenie elementów listy
print(lista)
print(lista_2)
# []
# []
#  dlaczego  obydwie listy sa puste  ??   hm
# wartości sa przekazywane przez referencje Python nie kopiuje danych tylko wskazuje ten sam adres
# przypisanie w przypadku kolekcji to nie jest kopia wartości tylko kopia referencji.

lista_copy=lista.copy()  # kopia elementów listy do nowej listy
lista.clear()  # czyszczenie elemeneów listy

print(lista)
print(lista_2)
print(lista_copy)   #['Radek', 'TOMEK', 'Grzegorz', 'Mikołaj', 'Zośka']


print(id(lista_2))  #  id adresy
print(id(lista))
print(id(lista_copy))
# 2009950494912
# 2009950494912
# 2009953336768
# referencje dotyczą wszystkiego poza prymityw innych obiektów, list etc

liczby=[54,999,34,22,12.34,687]

print(liczby)   #[54, 999, 34, 22, 12.34, 687]
print(type(liczby)) #<class 'list'>

# sortowanie listy

liczby.sort()
print(liczby)  # [12.34, 22, 34, 54, 687, 999]
liczby=[54,999,34,22,12.34,687,"a"]
print(type(liczby))

#liczby.sort() #  pytho nie potrafii sortować listy o róznych typach, umie porównać dany typ, ale nie potrafi sortować miedzy typami w jedej liście
print(liczby)

lista_litery = ["b","a", "z","w"]
lista_litery.sort()
print(lista_litery) #['a', 'b', 'w', 'z']

lista_litery.reverse() # odwrócenie listy
print(lista_litery) #['z', 'w', 'b', 'a']

# sortowanie z odwróceniem

lista_litery.sort(reverse=True)   # najpierw sortuje i później odwraca
print(lista_litery) # ['z', 'w', 'b', 'a']

print(lista_litery[::-1])  # powoduje wyśietlanie od tyłu   czyli start, stop i krok
# ['a', 'b', 'w', 'z']   choć w bazie lista wygląda   ['z', 'w', 'b', 'a']


liczby[3]=666
print(liczby[0:3])
print(liczby[-2])
print(liczby)
# [54, 999, 34]
# 687
# [54, 999, 34, 666, 12.34, 687, 'a']

print(liczby.pop(2)) # usuwa po indeksie   usunął 34
liczby.remove(54)
print(liczby)  #[999, 666, 12.34, 687, 'a']

del liczby  #  usunięcie listy
# print(liczby)  #  errror bo już nie ma listy


# rozpakowanie sekwencji

tekst = "Pyt hon."
lista1 = list(tekst)    # trkatuje kazdą litere jako element listy
print(lista1)  # ['P', 'y', 't', ' ', 'h', 'o', 'n', '.']

lista2 = [tekst]  # wstawia tekst jako elementem listy
print(lista2)  # ['Pyt hon.']

#________________________

krotka = tuple(lista_litery)
print(krotka)
print(type(krotka))
# ('z', 'w', 'b', 'a')
# <class 'tuple'>    # inny typ danych

