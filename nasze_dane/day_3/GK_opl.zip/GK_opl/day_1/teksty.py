tekst = ("Witaj Świecie")
print(tekst)

# wszystko jest obiektem
tekst.upper()
print(tekst)

# Witaj Świecie


print(tekst.count("i"))

tekst_zamiana = "Witaj dobry świecie"

print(tekst[4])  # indeks numer 4  -> j

encode_s = tekst.encode('utf-8')
print(encode_s)  # b'Witaj \xc5\x9awiecie'   litera b - oznacza że to typ bajtowy
print(type(encode_s))  # <class 'bytes'>

# odkodowanie
print(encode_s.decode("utf-8"))  # Witaj Świecie

imie = "Grzegorz"
# f - Fstring - tekst sformatowany
tekst_format = f"Mam na imię {imie} i ucze sie Pythona"
print(tekst_format)
tekst_format = f"\tMam na imię {imie}\n i ucze sie Pythona\b"
print(tekst_format)
# "	Mam na imię Grzegorz
#  i ucze sie Python
# \t - tabulator
# \n - nowa linia
# \b - backspace

starszy = "Witaj %s !"  # %s - string
print(starszy % imie)  # Witaj Grzegorz !  - pod %s wstawione zostanie wartość zmiennej imie

print("Witaj {}".format(imie))  # Witaj Grzegorz

print("Witaj", imie)  # Witaj Grzegorz

print("""
TEKST
        Wielolinijkowy
        """)
# TEKST
#        Wielolinijkow
#  ctlr / - komentarz
