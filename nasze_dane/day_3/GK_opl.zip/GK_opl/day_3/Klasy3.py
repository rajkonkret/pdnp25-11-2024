#
from abc import ABC, abstractmethod

class Ptak(ABC):
    """
    Klasa opisująca Ptaka w pythonie

    """
    def __init__(self,gatunek, szybkosc, piora="mam pióra"):
        """
        Metoda inicjalizująca (konstruktor)
        :param gatunek:
        :param szybkość:
        :param pióra:
        """
        self.gatunek = gatunek
        self.szybkosc = szybkosc
        self.piora = piora

    def latam(self):
        print("Tu ", self.gatunek, " latam z prędkoscią", self.szybkosc, "bo ", self.piora)

    @abstractmethod  # metoda abstrakcyjna
    def daj_glos(self):
        pass


class Kura(Ptak):  #" Kura dziedziczy po klasie Ptak"
    """
    Klasa Kra
    """
    def __init__(self,gatunek):
        super().__init__(gatunek, 0)

    def latam(self):
        print("Tu",self.gatunek, " Ja nie latam")

    def daj_glos(self):
        print("kokoko")

class Orzel(Ptak):
    def daj_glos(self):
        print("Kir Kier KIR")

# or1 = Ptak("Orzeł", 45)
# or1.latam()
#
# str1 = Ptak("Struś",60,"nie mam piór")
# str1.latam()
#
# wr1 = Ptak("wróbel", 30,)
# wr1.latam()

#  czy to porawnie wyśietla - > raczej nie,  można by IF, ale to nie obiektowo
#  na to włąsnie wymyslono
# dziedziczenie, po to by ominąć IFy
kur2 = Kura('Kura domowa')
kur2.latam()
or2 = Orzel("orzeł bielik",45)
or2.latam()

print(or2.daj_glos())

