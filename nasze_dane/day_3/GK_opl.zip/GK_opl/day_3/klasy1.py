# klasa - przepis szablon wg którego tworzymy efekt
# klasy mogą mieć cechy i funkcje
# posługujemy się obiektem "ciasto" zbudowane wg przepisu
#  klasa ma wyznaczaś standard
# Klasa musi być zadeklarowana , zdefiniowana
#  budowanie obiektu klasy uruchamia metode inicjalizujące
#  hermetyzacja, dzidziczenie, polimorfizm, abstrakcja

class Human:  # po dwukropku musi być przynajmniej jedna komenda  możę być pass lub wielolinijkowy komentarz
    """
    KLasa Human w pythonie
    """
    imie = ""
    wiek = None
    plec = "k"


# wielolinijkowy komentarz w funkcjach i klasach jest traktowany jako dokumentacja

print(Human.__doc__)  # KLasa Human w pythonie

cz1 = Human()  # tworzenie obiektu klasy
print(cz1)  # <__main__.Human object at 0x00000224E6C56900>
print(cz1.imie)  # ""
print(cz1.wiek)  # None
print(cz1.plec)  # k

# wartości nadajemy tak jak  inne zmienne
cz1.imie = "AnnA"
cz1.wiek = 51

print(cz1.imie)  # AnnA
print(cz1.wiek)  # 51
print(cz1.plec)  # k


cz2 = Human()
cz2.imie = "Marzcin"
cz2.wiek = 33
cz2.plec = "k"

print(cz2.imie) #  Marzcin
print(cz2.wiek) # 33
print(cz2.plec) #  k

