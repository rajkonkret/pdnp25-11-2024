# while - etla sterowana warunkiem
from operator import truediv

# pętla nieskończona

# while True:
#     print("komunikat nieskończony")


licznik = 0
while True:
    licznik += 1  # licznik = licznik + 1
    if licznik > 10:
        break  # przewanie pętli

print(licznik)  # 11   - petla okręci 11 razy 0 i powyżej 10

# inna notyfikacja  warunek w linii
# pętla mozę nie byc wykonana ani razu jesłi nie spełniony warunek
licznik = 0
while licznik < 10:
    licznik += 1
    print("komunikat ", licznik)

# lista = []
# lista_int = []
# while True:
#     wej = input("Podaj liczbę")
#     if not wej.isnumeric():  # isnumeric- sprawdza czy liczba  # A string is numeric if all characters in the string are numeric
#         break
#     lista.append(wej)
#     lista_int.append(int(wej))
#
# print(lista)  # ['2', '4', '3', '5']   - lista stringów
# print(lista_int)  # [2, 4, 3, 5] - lista wartości

# inne zastosowanie

my_list = [1, 5, 2, 3, 5, 4, 5, 6, 5]
# ctrl alt l
print( 5 in my_list)  #True
print(my_list)  # [1, 5, 2, 3, 5, 4, 5, 6, 5]
while 5 in my_list:
    my_list.remove(5)

print(my_list) #[1, 2, 3, 4, 6]
