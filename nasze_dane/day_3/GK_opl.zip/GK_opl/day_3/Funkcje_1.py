# Funkcje - wydzielony frament kodu, który mozna uruchomić w dowolnym momencie
# funkcja musie być zadeklarowana
# w miejscu deklaracji nic się nie uruchamia
# aby uruchomić fukkcjr=ę nalezy ją wywołać


a = 8
b = 6


# def   - definicja funkcji
# PEP8  - dwie linijki odstępu od reszty programu
def dodaj():
    print(a + b)


def dodaj2(a, b):  # dwa obowiązkowe argumenty, nie da się wywołać bez argumentów
    print(a + b)


def odejmij(a, b, c=0):  # definicja argumentu opcjonalnego
    print(a - b - c)


# uruchomienie funkji
dodaj()  # 14

# dodaj2()  # TypeError: dodaj2() missing 2 required positional arguments: 'a' and 'b'
# argumenty przekazywane po pozycji

dodaj2(5, 89)  # 94
odejmij(1, 2)  # -1
odejmij(1, 2, 3)  # -4

# przekazywanie argumentów po nazwie

odejmij(b=9, a=19)  # 10
odejmij(b=9, a=19, c=87)  # -77
# mieszane argumenty

odejmij(1, c=87, b=12)


# pozycu=yjne argumenty musza być przed nazwanymi

# print(dodaj() + odejmij(6, 9))
# TypeError: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
# w funkcjach nie ma zwrotu wyniku, tylko drukowanie na ekranie

# print(dodaj()) TypeError: unsupported operand type(s) for +: 'NoneType' and 'NoneType'

# ----------------------------------------------------
# Funkcje zwracające wynik
# Funkcje zwracające wynik kończa się słówkiem return

def dodaj3(a, b):
    return a + b  # zwróć wynik


dodaj3(4, 7)
print(dodaj3(4, 7))  # 11

wyn = dodaj3(5, 8)
print("wynik  ", wyn)  # wynik   13

print(dodaj3(5, 9) + dodaj3(2, 88))  #104
