# DZIAŁANIA Z PLIKAMI

#  najpierw powinniśmysprawdzić czy plik istnieje i czy mamy uprawnienia np do zapisu
#
# filehandler
# with - kontekst manadzer
# #    Character Meaning
#     --------- ---------------------------------------------------------------
#     'r'       open for reading (default)
#     'w'       open for writing, truncating the file first
#     'x'       create a new file and open it for writing
#     'a'       open for writing, appending to the end of the file if it exists
#     'b'       binary mode
#     't'       text mode (default)
#     '+'       open a disk file for updating (reading and writing)
#     ========= ===============================================================

with open("test.log","w") as fh:
    fh.write("Powitanie\n")
    fh.write("drugie\n")
    fh.write("kolejne\n")



# with open("test.log",x) as fh
#     fh.write("Powitanie\n")


# w - nadpisanie
# with open("test.log",w) as fh
#     fh.write("Powitanie\n"

# dopisanie
# with open("test.log",a) as fiele:
#     fiele.write("Powitanie\n"


# odczytywanie z literką r




