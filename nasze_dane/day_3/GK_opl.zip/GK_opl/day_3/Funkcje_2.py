a = 10
b = 10


def dodaj():
    a = 7
    b = 8
    print(a + b)

print(f'Wartość a z góry {a=}  {b}(globalne')
dodaj()
print(f'Wartość a z góry {a=} {b=} (globalne)')
# Wartość a z góry a=10  10(globalne
# 15
# Wartość a z góry a=10 b=10 (globalne)


def dodaj2():
    global a  # do działań wykorzysta globalne a
    a = 9   # użyje globalne a
    b = 89
    print(a + b)
# jak wyżej nie powinno się tak stosować bo trudno w programiei znaleźć miejsce gdzie zmienia się wartość globalna
#  wartość branej do wyliczeń zależna od  tego kiedy zostanie wywołana funkcja
# jestprzez dodaj2 to inne wartości i inne po wywołaniu dodaj2 która zmienia warość a
print(f'Wartość a z góry {a=}  {b}(globalne)')
dodaj2()
print(f'Wartość a z góry {a=} {b=} (globalne)')

# Wartość a z góry a=10  10(globalne)
# 98
# Wartość a z góry a=9 b=10 (globalne)



