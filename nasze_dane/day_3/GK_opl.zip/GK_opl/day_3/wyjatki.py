# wyjątki - błedy generowane przez działanie programu

# print(5/0)
# C:\Users\CSComarch\AppData\Local\Programs\Python\Python313\python.exe C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024\nasze_dane\GK_opl\day_3\wyjatki.py
# Traceback (most recent call last):
#   File "C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024\nasze_dane\GK_opl\day_3\wyjatki.py", line 3, in <module>
#     print(5/0)
#           ~^~
# ZeroDivisionError: division by zero
#
# Process finished with exit code 1

try:
    # print(5 / 0)
    # print("A"+9)
    # print(int("A"))
    # raise KeyError(" Brak Klucza")
    wynik = 90/34
except ZeroDivisionError:
    print("Nie dziel cholero nigdy przez zero")
except TypeError:
    print("Bład typu")
except ValueError:
    print("Bład Wartości")
except Exception as e:
    print("Błąd  :", e)
else:  # tylko gdy nie ma błędu
    print("Wynik :", wynik)
finally:   # musi być na końcu
    print("Wykona się zawsze bez względu czy był bład czy nie",)

print("Dalsza cześć programu")

# Nie dziel cholero nigdy przez zero
# Dalsza cześć programu
# try - except [else - finally]

