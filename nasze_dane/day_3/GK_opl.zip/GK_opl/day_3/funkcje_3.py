# funkcja Lambda  w java script nazywa się fuk=nkcja strzałka
# skrócony zapis funkcji
# lambda zawsze zwraca wynik czyli domyślnie ma return na końcu
# występuje jako funkcja anonimowa

def odejmij(a, b):
    return a - b


print(odejmij(8, 4))  # 4
odejmij2 = lambda a, b: a - b
print(odejmij2(45, 5))  # 40

wiek = lambda x: "dziecko" if x < 10 else ("nastolatek" if x < 18 else "Dorosły")

print(wiek(9))  # dziecko
print(wiek(10))  # nastolate
print(wiek(17))  # nastolate
print(wiek(18))  # Dorosły
print(wiek(25))  # Dorosły
print(wiek(32))  # Dorosły

# 3 --------------------

lista = [1, 2, 3, 10, 20, 30, 100, 200, 500]
# zadanie przemnożyć kazdy element przrz 2

print([i * 2 for i in lista])

lista_wyn = []


def zmien(x):
    return x * 2

for i in lista:
    lista_wyn.append((i))
print(lista_wyn) # [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# map() - mapowanie danych , zmiana danych wg zadanej funkcji

print(f'Zastosowanie map() {list(map(zmien, lista))}')

#Zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]


# lambda jako funckaj anonimowa - oznacza wykonanie w miejscu deklaracji

print(f'Zastosowanie map() {list(map(lambda x: x*2, lista))}')
print(f'Zastosowanie map() {list(map(lambda x: x*4, lista))}')
print(f'Zastosowanie map() {list(map(lambda x: x*5, lista))}')
print(f'Zastosowanie map() {list(map(lambda x: x/2, lista))}')
# Zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]
# Zastosowanie map() [4, 8, 12, 40, 80, 120, 400, 800, 2000]
# Zastosowanie map() [5, 10, 15, 50, 100, 150, 500, 1000, 2500]
# Zastosowanie map() [0.5, 1.0, 1.5, 5.0, 10.0, 15.0, 50.0, 100.0, 250.0]



# ----------------------------------
# filtrowanie danych
#
# filter() - zwracaelementy spełniająe warunek zadany funkcją
#  funkcje wyższego rzedu

print(f'Zastosowanie filter {list(filter(lambda x: x<3, lista))}')
# Zastosowanie filter [1, 2]
print(f'Zastosowanie filter {list(filter(lambda x: x<20, lista))}') #Zastosowanie filter [1, 2, 3, 10]
print(f'Zastosowanie filter {list(filter(lambda x: x>20 and x<80, lista))}') # Zastosowanie filter [30]
print(f'Zastosowanie filter {list(filter(lambda x: 20<x<200, lista))}') #Zastosowanie filter [30, 100]


