# pętle - możliwość wykonywania tego samego kod wielokrotnie
# for - pętla iteracyjna sterowana licznikiem
import random  # do działań na liczbach pseudolosowych

for i in range(5):
    print(i)
#  wynik
# 0
# 1
# 2
# 3
# 4

#
# for i in range(1000):
#     pass # komenda nie robiąca nic  - nie można zostawić pustej pętli
#
# for _ in range(10):  # prawidłwow, gdy nie potrzebujemy indeksu pętli do wykorzystania nz się niema zmienna
#     print("To jest pętla")
#     print(_)

# losowanie
# print(random.randint(a:1,b:100)) #
print(random.randint(1, 100))  # od 1 do 100
print(random.randrange(1, 100))  # od 1 do 99
print(random.randrange(6))  # od 0 do 5
print(random.random())  # float od 0 do 0,9999999

lista = [67, 45, 32, 68, 89, 90, 42]  # jakwylosować element z listy

print(random.choice(lista))  # 68  losuje z listy

lista_kule = list(range(1, 50))  # generuje listę
# [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49]

print(lista_kule)

lista_losowana = []
for _ in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_losowana.append((wyn))

print(lista_losowana)  # [37, 32, 2, 6, 12, 36]

print(random.choices(lista_kule, k=6))  # choices losuje z powtórzeniami
print(random.sample(lista_kule, k=6))  # losuej unikalne wartości  [3, 9, 4, 25, 46, 27]

# ___________________________

for i in range(10):
    if i % 2 == 0:
        print(i, "parzysta")
# 0 parzysta
# 2 parzysta
# 4 parzysta
# 6 parzysta
# 8 parzysta

# list comprehensions
lista_3 = [j for j in range(10) if j % 2 == 0]  # [0, 2, 4, 6, 8]
print(lista_3)   # [0, 2, 4, 6, 8]

for c in lista_losowana:   # przykłąd pętli po kolekcji
    if c>10:
        print("Wieksze od 10")
    else:
        print("Mniejsze od 10")
# Wieksze od 10
# Wieksze od 10
# Wieksze od 10
# Wieksze od 10
# Wieksze od 10
# Mniejsze od 10

# ------------------------- iteracje po słownikach

dictionary = {"imie":" Grzegorz", "nazwisko":"Kowalski"}  # słownik
# wyświetli klucze
for i in dictionary:
    print(i)
# imie
# nazwisko

# to samo inaczej
for k in dictionary.keys():
    print(k)

 # wyświetl wartości
for v in dictionary.values():
    print(v)
#  Grzegorz
# Kowalski

for i in dictionary.items():
    print(i)
# ('imie', ' Grzegorz')
# ('nazwisko', 'Kowalski')  #   wynikiem losowania ze słownika są krotki (tuple)


# k,v = ("nazwisko", "kowalski")
# rozpakowanie krotki
for k,v in dictionary.items():
    print(k,"=>", v)

# imie =>  Grzegorz
# nazwisko => Kowalski
