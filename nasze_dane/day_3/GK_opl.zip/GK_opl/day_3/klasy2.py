class Human:
    """
    KLasa Human
    """

    # Funkcje w klasie nazywają się metody
    # inicjowanie klasy
    def __init__(self, imie, wiek, wzrost, plec="k"):  # przykład wartości domyślnek  plec = "k"
        """
        Metoda inicjująca (konstruktor)

        :param imie:
        :param wiek:
        :param wzrost:
        :param plec:
        """
        self.imie = imie
        self.wiek = wiek
        self.wzrost = wzrost
        self.plec = plec

    def powitanie(self):
        print("Mam na imię: ", self.imie)


cz1 = Human("Anna", 30, 158)

print(cz1.imie)  # Anna
print(cz1.wiek)  # 30
print(cz1.wzrost)  # 158
print(cz1.plec)  # k

cz2 = Human("GREG", 33, 168, "m")
print(cz2.imie)  # GREG
print(cz2.wiek)  # 33
print(cz2.wzrost)  # 168
print(cz2.plec)  # m
# klasy mogą mieć pola i metody

cz3 = Human("Jacek", 55, 155, plec="m")

cz1.powitanie()  # Mam na imię:  Anna
cz2.powitanie()  # Mam na imię:  GREG
cz3.powitanie()  # Mam na imię:  Jacek

lista = [cz1, cz2, cz3]

for i in lista:   # szuka po elementach
    i.powitanie()

# wynik petelki
# Mam na imię:  Anna
# Mam na imię:  GREG
# Mam na imię:  Jacek
