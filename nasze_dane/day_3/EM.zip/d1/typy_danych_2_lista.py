lista = []
print(lista)
print(type(lista))
pusta_lista = list()
print(pusta_lista)
print(type(pusta_lista))

lista.append("Emi")
lista.append("Kasia")
lista.append("Jadzia")
lista.append("Kazio")
lista.append("Darek")
lista.append("OLA")
lista.append("Krzyś")

print(lista)

print(lista[0])
print(lista[1])
print(lista[2])

print(len(lista))
print(lista[6])

print(lista[len(lista)-1])
print(lista[-1])
print(lista[-2])
print(lista[-3])

print(lista[0:3])
print(lista[:3])
print(lista[2:])
print(lista[2:5])

print(lista[2:10])
print(lista[10:20])
print(lista[2:2])
print(lista[2:3])

print(lista[:])
print(lista[-2:0])
print(lista[0:-2])

lista_15 = list(range(15))
print(lista_15)

print(lista_15[0:15:2])
print(lista_15[-10])

lista[3] = "Mikołaj"
print(lista)

lista.insert(1,"Marek")
print(lista)

print(lista.index("OLA"))

lista.append("Zenek")
print(lista)
lista.remove("Zenek")
print(lista)

print(lista.pop(5))
print(lista)
print(lista.pop())
print(lista)

a = 1
b = 3
print(a,b)
a = b
print(a,b)
b = 7
print(a,b)
print(f"{a=},{b=}")

lista_2 = lista
lista.clear()
print(lista)
print(lista_2)
lista_copy = lista.copy()
lista.clear()
print(lista)
print(lista_2)
print(lista_copy)

liczby = [54,999,34,22,12,34,687]
print(liczby)
print(type(liczby))

liczby.sort()
print(liczby)

liczby = [54,999,34,22,12,34,687,"A"]
print(type(liczby))

lista_litery = ["b","a","z"]
lista_litery.sort()
print(lista_litery)

lista_litery.reverse()
print(lista_litery)

lista_litery.sort(reverse=True)
print(lista_litery)

print(lista_litery[::-1])

liczby[3] = 666
print(liczby[0:3])
print(liczby[-2])
print(liczby.pop(2))

liczby.remove(54)
print(liczby)


del liczby
# print(liczby)

tekst = "Pyt hon."
lista1 = list(tekst)
print(lista1)

lista2 = [tekst]
print(lista2)

krotka = tuple(lista_litery)
print(krotka)
print(type(krotka))


