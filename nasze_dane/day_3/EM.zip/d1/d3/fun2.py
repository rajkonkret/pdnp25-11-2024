a=10
b=10


def dodaj():
    a=7
    b=8
    print(a+b)

def dodaj2():
    a=9
    b=89
    print(a+b)

def dodaj3():
    a=9
    b=89
    print(a+b)
    
print(f"Wartość a z góry {a=} {b} (globalne)")
dodaj()
print(f"Wartość a z góry {a=} {b} (globalne)")
dodaj3()
print(f"Wartość a z góry {a=} {b} (globalne)")
dodaj2()
print(f"Wartość a z góry {a=} {b} (globalne)")
dodaj3()
print(f"Wartość a z góry {a=} {b} (globalne)")