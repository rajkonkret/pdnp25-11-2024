# petla nieskończona

# while True:
#     print("komunikat !!!")
#
# licznik = 0
# while True:
#     licznik += 1
#     print("komunikat 2 !!!")
#     if licznik > 10:
#         break
#
# print(licznik)
#
# licznik = 0
# while licznik < 10:
#     licznik += 1
#     print("Komunikat 3 !!!")
#
# lista = []
# lista_int = []
# while True:
#     wej = input("Podaj liczbę")
#     if not wej.isnumeric():
#         break
#     lista.append(wej)
lista = []
lista_int = []
print(lista)
print(lista_int)

my_list = [1, 5, 2, 3, 5, 4, 6]

print(5 in my_list)
while 5 in my_list:
    my_list.remove(5)

print(my_list)


