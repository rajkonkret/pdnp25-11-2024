# wyjatki - błędy generowane przez działanie programu

# print(5/0)
# print("Dalsza częśc programu")
#
# try:
# #     # print(5/0)
# print("a"+9)

try:
    wynik = 90/34

except ZeroDivisionError:
    print("Nie dziel przez zero")
except TypeError:
    print("Błąd typu")
except Exception as e:
    print("Błąd e")
except ValueError:
    print("Błąd wartości")
else:  # tylko gdy nie ma błędu
    print("wynik", wynik)
finally:
    print("wykona się zawsze")
print("Dalsza część programu")
