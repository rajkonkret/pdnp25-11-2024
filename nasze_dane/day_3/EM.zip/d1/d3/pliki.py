with open('test.log','w') as fh:
    fh.write('Powitanie\n')
    fh.write('Drugie\n')
    fh.write('Kolejne\n')


with open('test.log', 'w') as fh:
    fh.write('NADpisanie\n"')


with open("test.log","a") as file:
    file.write("Dopisane\n")

with open("test.log","a",encoding='utf-8') as file:
    file.write("Dopisane\n")
with open("test.log", "a", encoding='utf-8') as file:
    file.write("Dopisane\n")