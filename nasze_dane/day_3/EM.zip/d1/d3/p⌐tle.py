# for petla

import random # działa na liczbach seudolosowych
for i in range (5):
    print(i)

for i in range(1000):
    pass

for _ in range(10): # niema zmienna
    print("To jest pętla")
    print(_)

print(random.randint(1,100))
print(random.randrange(1,100))
print(random.randrange(6))
print(random.random())

lista = [67,45,32,68,89,90,42]
print(random.choice(lista))
lista_kule = list(range(1,50))
print(lista_kule)

lista_wylosowana = []
for _ in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)

print(lista_wylosowana)

print(random.choices(lista_kule, k=6)) # losuje z powtórzeniami
print(random.sample(lista_kule, k=6))

for i  in range(10):
    if i % 2 ==0:
        print(i, "parzysta")
lista3 = [j for j in range(10) if j%2 ==0]
print(lista3)

for c in lista_wylosowana:
    if c>10:
        print("Większe od 10)")
    else:
        print("Mniejsze lub równe od 10")

dictionary = {'imię': "Radek", 'nazwisko' : "Kowalski"}
for i in dictionary:
    print(i)

for k in dictionary.keys():
    print(k)

for v in dictionary.values():
    print(v)

for i in dictionary.items():
    print(i)

for k,v in dictionary.items():
    print(k, "=>", v)

