class Human:
    """
    Klas Human
    """

    def __init__(self, imie, wiek, wzrost, plec="k"):
        """
        Metoda inicjalizująca
        :param imie:
        :param wiek:
        :param wzrost:
        :param plec:
        """
        self.imie = imie
        self.wiek = wiek
        self.wzrost = wzrost
        self.plec = plec

    def powitanie(self):
        print("Mam na imię", self.imie)


cz1 = Human("Anna", 27, 168)
print(cz1.imie)
print(cz1.wiek)
print(cz1.wzrost)
print(cz1.plec)

cz2 = Human("Ewa", 1, 80)
print(cz2.imie)
print(cz2.wiek)
print(cz2.wzrost)
print(cz2.plec)

cz3 = Human("Olek", 13, 150, plec="m")
print(cz3.imie)
print(cz3.wiek)
print(cz3.wzrost)
print(cz3.plec)

cz2.powitanie()
cz1.powitanie()
cz3.powitanie()

lista = [cz1, cz2]
for i in lista:
    i.powitanie()
