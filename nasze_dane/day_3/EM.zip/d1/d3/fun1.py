# funkcje - wydzielony fragment kodu, który mozna uruchomić w dowolnym momencie
# funkcja musi byc najpierw zadeklarowana
# w miejscu deklaracji nic się nie uruchamia
# aby uruchomic funkcje najeży ją wywołac

a = 8
b = 6


# deklaracja funkcji

# PEP8 - dwie linijki odstępu od reszty porgramu

def dodaj():
    print(a + b)


def dodaj2(a, b):
    print(a + b)
    # uruchamianie funkcji


def odejmij(a, b, c=0):
    print(a - b - c)


dodaj()
dodaj2(5, 89)
odejmij(1, 2)
odejmij(1, 2, 3)

odejmij(b=9, a=19)
odejmij(b=9, a=19, c=87)

odejmij(1, c=87, b=12)


# print(dodaj()+odejmij(6,9))

def dodaj3(a, b):
    return a + b  # zwróć wynik


print(dodaj3(4, 7))
wyn = dodaj3(5, 8)
print("Wynik", wyn)
print(dodaj3(5, 9) + dodaj3(2, 89))

