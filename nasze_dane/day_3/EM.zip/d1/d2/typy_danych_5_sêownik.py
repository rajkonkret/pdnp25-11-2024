#{"user" : "Radek", "wiek" : 78}
#{"klucz" : "wartość"}
#{"firstName":"John","LastName":"Doe"}

#klucze nie moga się powtarzać

# pusty słownik

dictionary = dict()
print(dictionary)

dictionary_1 = {}
print(dictionary_1)
print(type(dictionary_1))

dictionary['imie'] = "Radek"
print(dictionary)
dictionary ['wiek'] = "45"
print(dictionary)

# nadpisanie elemntu

dictionary['imie'] = "Tomek"
print(dictionary)

print(dictionary.values())
print(dictionary.items())
print(dictionary.keys())

# wypisanie elementu ze słownika

print(dictionary['imie'])
print(dictionary['wiek'])

# print(dictionary['Imie'])

print(dictionary.get("Imie"))
print(dictionary.get("Imie", 'default')),

dictionary.update({"date":"12-12-2024"})
print(dictionary)

dict_small = {"x":2}
dict_small.update([('y',3),("z",7)])
print(dict_small)

#input() pobiera dane od użytkownika

# tekst = input("Podaj imię")
# print(tekst)
# print(type(tekst))

#pobrac dwie liczby
#wypisac wynik dodawania

# liczba = input("liczba")
# liczba2 = input("liczba")
# print(int(liczba) + int(liczba2))

#napisać aplikację  pl-ang
# słownik ze słówkani i tłumaczeniami
słownik = {"dom": "home", }
