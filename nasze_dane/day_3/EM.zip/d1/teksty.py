tekst = "Witaj Świecie"
print(tekst)
print(type(tekst))
""" Return a copy of the string converted to uppercase. """
tekst.upper()
print(tekst.upper())
print(tekst)
tekst_upper = tekst.upper()
print(tekst_upper)
tekst.lower()
print(tekst.lower())

print(tekst.count("i"))
print(tekst.count("j",0,4))

tekst_zamiana="Witaj dobry Świecie"
print(tekst_zamiana.replace("dobry",""))
print(tekst_zamiana.replace("dobry ",""))
print(tekst.removeprefix("Witaj"))
print(tekst.removeprefix("Witaj").strip())
print(tekst.removesuffix("Świecie"))
print(tekst.removesuffix("Świecie").strip())

print(tekst[4])

encode_s = tekst.encode('utf-8')
print(encode_s)
print(type(encode_s))

print(encode_s.decode('utf-8'))

imie = "Ewa"

tekst_format= f"Mam na imię {imie} i lubię pythona"
print (tekst_format)

tekst_format = f"\tMam na imię {imie}\n i lubię pythona.\b"
print(tekst_format)

starszy = "Witaj %s!"
print(starszy % imie)

print("Witaj {}".format(imie))

print("Witaj", imie)

print("""   
Tekst 
    wielolinijkowy
""")

