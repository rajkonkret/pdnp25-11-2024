user = "Tomek"
wiek = 39
wersja = 3.90001
print(type(wersja))
liczba = 6578973746

print("Witaj %s, masz teraz %d lat" %(user,wiek))

print("Witaj %(user)s, Lubię Cię %(user)s" % {"user":user})
print("Witaj {}, masz teraz {} lat.".format(user,wiek))

print(f"Witaj {user},masz teraz {wiek} lat")

print("Używamy wersji pythona %i" % 3)
print("Używamy wersji pythona %f" % 3)
print("Używamy wersji pythona %.2f" % 3.9)
print("Używamy wersji pythona %.1f" % 3.9)
print("Używamy wersji pythona %.0f" % 3.9)
print("Używamy wersji pythona %.f" % 3.9)

wynik = 3.8765
print("Wynik = %.2f" % wynik)
print("wynik nadal nie zmieniony", wynik)

print(f"Używamy wersji pythona {wersja}")
print(f"Używamy wersji pythona {wersja:.1f}")
print(f"Używamy wersji pythona {wersja:.2f}")
print(f"Używamy wersji pythona {wersja:.0f}")
# print(f"Używamy wersji pythona {wersja:.f}")

print(f"{user:>10}")
print(f"{user:<15}")
print(f"{user:^20}")
print(liczba)
print(f"Nasza duża liczba {liczba:,}")
print(f"Nasza duża liczba {liczba:_}")
print(f"Nasza duża liczba {liczba:_}".replace("_","."))
print(f"Nasza duża liczba {liczba:_}".replace("_"," "))
liczba_2 = 150_000_000_000
print(liczba_2)
print(type(liczba_2))

