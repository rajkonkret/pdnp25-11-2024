import pandas as pd

# pip install pandas

data = pd.read_csv('dane.csv')

print(data)
#               Kowalski       Jan              Kłodzko
# 0                Nowak     Zenon             Szczecin
# 1  Brzęczyszczykiewicz  Grzegorz  Chrząszczyżewoszyce