a = 10
b = 10


def dodaj():
    a = 7
    b = 8
    print(a + b)


def dodaj2():
    global a
    a = 9
    b = 89
    print(a + b)


print(f"Wartośc a z góry {a=} {b=} (globalne)")
dodaj()
print(f"Wartośc a z góry {a=} {b=} (globalne)")
dodaj2()
print(f"Wartośc a z góry {a=} {b=} (globalne)")
