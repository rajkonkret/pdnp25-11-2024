from abc import ABC, abstractmethod
class Ptak:
    """
    Klasa opisująca ptaka w pythonie
    """
    def __init__(self,gatunek,szybkosc):
        """
        Metoda inicjująca
        :param gatunek:
        :param szybkosc:
        """
        self.gatunek=gatunek
        self.szybkosc=szybkosc
    def latam(self):
        print("Tu",self.gatunek, "lece",self.szybkosc)
    @abstractmethod
    def wydaj_odglos(selfself):
        pass

class Kura(Ptak):
    """Klasa kura"""
    def __init__(selfself,gatunek):
        super().__init__(gatunek,0)
    def latam(self):
        print("TU", self.gatunek,"Ja nie latam")
    def wydaj_odglos(self):
        print("ko ko ko")
class Orzel (Ptak):
    """
    Klasa Orzeł
    """
    def wydaj_odglos(self):

#or1=Ptak("Orzel",45)
#or1.latam()
#kur1=Ptak("Kura",0)
#kur1.latam()


kur2 = Kura("kura domowa")
kur2.latam()