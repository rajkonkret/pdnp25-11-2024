import random

for i in range(5):
    print(i)

for i in range(1000):
    pass

for _ in range(10):
    print("To jest petla")

print(random.randint(1, 100))

lista = [67, 45, 32, 68, 89, 90, 42]
print(random.choice(lista))
lista_kule = list(range(1, 50))
print(lista_kule)

lista_wylosowana = []
for _ in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)
print(lista_wylosowana)
print(random.choices(lista_kule, k=6))  # lisuje z powtórzeniami
print(random.sample(lista_kule, k=6))  # losuje unikalne wartości

for i in range(10):
    if i % 2 == 0:
        print(i, "parzysta")
lista3 = [j for j in range(10) if j % 2 == 0]
print(lista3)

for c in lista_wylosowana:
    if c > 10:
        print("wieksze 10")
    else:
        print("mniejsze 10")

dictionary = {'imie': "radek", 'nazwisko': "Kowalski"}

for i in dictionary:
    print(i)

for k in dictionary.keys():
    print(k)

for v in dictionary.values():
    print(v)

for i in dictionary.items():
    print(i)

for k, v in dictionary.items():
    print(k, "=>", v)

licznik = 0
while licznik < 10:
    licznik += 1
    print("komunikat")

lista = []
lista_int = []
while True:
    wej = input("podaj liczbe")
    if not wej.isnumeric():
        break
    lista.append(wej)
    lista_int.append(int(wej))
print(lista)
print(lista_int)


