lista=[]
lang=input("Podaj znany jezyk programowania")
match lang.casefold().strip():
    case "python":
        lista.append("znam pythona")
    case"java":
        lista.append("znam java")
    case _:
        print("nie znam")
print(lista)