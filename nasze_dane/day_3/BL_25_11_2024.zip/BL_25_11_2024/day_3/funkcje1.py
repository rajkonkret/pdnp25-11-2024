a=8
b=6


def dodaj():
    print(a+b)


def dodaj2(a , b):
    print(a+b)


def odejmij (a, b, c=0):
    print(a-b-c)


dodaj()
dodaj2(5,80)
odejmij(1,2)
odejmij(1,2,6)

odejmij(b=9, a=19)
odejmij(b=9, a=19, c=87)

odejmij (1,c=87,b=12)


def dodaj3(a,b):
    return a +b

print(dodaj3(4,7))
wyn=dodaj3(5,8)
print("wynik", wyn)
print(dodaj3(5,9)+dodaj3(2,89))