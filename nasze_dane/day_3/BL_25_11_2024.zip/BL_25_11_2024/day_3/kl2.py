class Human:

    """
    Klasa Human
    """

    def __init__(self, imie, wiek, wzrost, plec="k"):
        """
        Metoda inicjujacq
        :param imie:
        :param wiek:
        :param wzrost:
        :param plec:
        """
        self.imie=imie
        self.wiek=wiek
        self.wzrost=wzrost
        self.plec=plec

    def powitanie(self):
        print("Mama na imie",self.imie)


cz1 = Human("Karol", 27, 168, 'm')
cz2 = Human("Anna", 25, 168, 'm')
print(cz1.imie)
print(cz1.wiek)
print(cz1.wzrost)
print(cz1.plec)
print()
cz2.powitanie()
cz1.powitanie()


