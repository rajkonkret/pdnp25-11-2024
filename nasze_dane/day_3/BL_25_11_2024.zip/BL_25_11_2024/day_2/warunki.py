odp=True
print(bool(odp))
if odp:
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
print("Dalsza czsc programu")

if odp=="Tomek":
    print('To  jest Tomek')
else:
    print('To nie jest tonek')

podatek=0
zarobki=int(input("Podaj zarobki"))
if zarobki<10000:
    podatek=0
elif zarobki<100000:
    podatek=0.4
elif zarobki<30000:
    podatek=0.2
else:
    podatek=0.9
print("Podatek wynosi",podatek*zarobki)

suma_zam =150
if suma_zam>100:
    rabacik=25
else:
    rabacik=0
print(f"rabat wynosi{rabacik}")


rabat=25 if suma_zam>100 else 0
print(f"rabat wynosiu{rabat}")

if odp=="RADEK":
    if suma_zam >50:
        rabat=200
print(f"rabatab{rabat}")