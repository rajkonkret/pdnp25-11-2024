# pętla - daje możliwość wykonania tego samego kodu wielokrotnie
# for - pętla iteracyjna
import random # do działań na liczbach pseudolosowaych

for i in range(5): # od 0 do 4
    print(i)
# 0
# 1
# 2
# 3
# 4

for i in range(1000):
    pass  # nic nie rób, kończy pętlę

for _ in range(10): # nie ma zmienna
    print("to jest pętla")
    # print(_)

print(random.randint(1, 100))  # od 0 do 100
print(random.randrange(1, 100)) # od 1 do 99
print(random.randrange(6)) # od 0 do 5
print(random.random()) # 0.4697274378812959

lista=[67,45,32,68,89,90,42]
print(random.choice(lista)) # 32

lista_kule=list(range(1,50))
print(lista_kule)

lista_wylosowana=[]
for _ in range(6):
    wyn=random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)

print(lista_wylosowana) # [2, 1, 21, 43, 31, 41] losuje bez powtórzeń

print(random.choices(lista_kule, k=6)) # [19, 3, 31, 40, 20, 10] losuje z powtórzeniami choices
print(random.sample(lista_kule, k=6)) # [29, 24, 2, 16, 38, 19] losuje bez powtórzeń

for i in range(10):
    if i % 2==0:
        print(i, "parzysta")

# 0  2 4 6 8 parzysta

lista3=[j for j in range(10) if j % 2 ==0]
print(lista3) # [0, 2, 4, 6, 8]

for c in lista_wylosowana:
    if c >10:
        print("większe od 10")
    else:
        print("mniejsze lub równe od 10")
#większe od 10
# mniejsze lub równe od 10
# większe od 10
# większe od 10
# większe od 10


dictionary={'imię': "Radek", 'nazwisko': "Kowalski"}  # słownik

# wyświetli klucze
for i in dictionary:
    print(i)
# imię
# nazwisko

# wyświetlić wartości
for v in dictionary.values():
    print(v)
# Radek
# Kowalski

# pary - typ danych krotka, nawiasy okrągłe
for i in dictionary.items():
    print(i)
# ('imię', 'Radek')
# ('nazwisko', 'Kowalski')

# rozpakowanie krotki powyżej
for k,v in dictionary.items():
    print(k,  "=>", v)
# imię => Radek
# nazwisko => Kowalski
