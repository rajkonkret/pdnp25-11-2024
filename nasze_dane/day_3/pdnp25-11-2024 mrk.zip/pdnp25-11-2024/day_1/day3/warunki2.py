# od pythona 3.10
# match case

lista = []
lang = input("Podaj znany Ci język programowania")

match lang.casefold().strip():
    case "python":
        lista.append("Znam Pythona")
    case "java":
        lista.append("java")
    case _: #odpowiednik elsce
        print("nie znam takiego jężyka")

print(lista)
# Podaj znany Ci język programowaniajava
# ['java']

