# while - pętla sterowana warunkiem

# while True:
#    print("komunikat !!!") # pętla nieskończona

licznik=0
while True:
    licznik +=1 # licznik=licznik+1
    print("komunikat 2 !!!")
    if licznik>10:
        break #przerywamy pętlę

print(licznik) #11

licznik=0
while licznik <10:
    licznik+=1
    print("Komunikat 3 !!!")

lista=[]
lista_int=[]
# a string is numeric if all characters in the string are numeric - opis funkcji komentarze ctrl +lewy przyciks myszy
while True:
    wej = input("Podaj liczbę")
    if not wej.isnumeric():
        break
    lista.append(wej)
    lista_int.append(int(wej))

print(lista) # ['23', '24', '22']
print(lista_int) # [23, 24, 22]

my_list=[1,5,2,3,4,5,6,5]
# ctrl alt l
print(5 in my_list)
while 5 in my_list:
    my_list.remove(5)

print(my_list)
# True
# [1, 2, 3, 4, 6]


