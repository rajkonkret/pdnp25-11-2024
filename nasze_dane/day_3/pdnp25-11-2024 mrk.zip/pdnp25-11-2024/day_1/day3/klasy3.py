class Ptak:
    """
    klasa opisująca ptaka w pythonie
    """


    def __init__(self, gatunek, szybkosc):
        """
        Metoda inicjalizująca (konstruktor)
        :param gatunek:
        :param szybkosc:
        """

        self.gatunek = gatunek
        self.szybkosc = szybkosc

    def latam(self):
        print("Tu", self.gatunek, "lecę z szybkością", self.szybkosc)


class Kura(Ptak):
        """Klasa Kura"""

    def __init__(self, gatunek)
        super().__init__(gatunek, 0)

    def latam(self):
        print("Tu", self.gatunek, "Ja nie latam")


or1=Ptak("orzeł", 45)
or1.latam()  #  Tu orzeł lecę z szybkością 45
kur1=Ptak("kura", 0)
kur1.latam()


# metoda abstakcyjna
class Ptal()


