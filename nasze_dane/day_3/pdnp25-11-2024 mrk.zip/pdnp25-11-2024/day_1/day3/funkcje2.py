a =10
b =10

def dodaj():
    # lokalne zmienne, od deklaracji w prawo
    a=7
    b=8
    print(a+b)

def dodaj2():
    global a
    a=9  #  użyje globalnego a i zminia jego wartość tego podanego na górze
    b=89
    print(a+b)

def dodaj3():
    print(a+b)

print(f"Wartość a z góry {a=}  {b=} (globale)") #  Wartość a z góry a=10  b=10 (globale)
dodaj()  # 15
print(f"Wartość a z góry {a=} {b=} (globale)")  # Wartość a z góry a=10 b=10 (globale)
dodaj2()  # 98
print(f"Wartość a z góry {a=} {b=} (globalne)")  # Wartość a z góry a=9 b=10 (globalne)
dodaj3()  # 19
print(f"Wartość a z góry {a=} {b=} (globalne)")  # Wartość a z góry a=9 b=10 (globalne)

