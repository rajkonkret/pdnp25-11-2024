# wyjątki -

# print(5/0)
# Traceback (most recent call last):
#   File "C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024\day_1\day3\wyjatki.py", line 3, in <module>
#     print(5/0)
#           ~^~
# ZeroDivisionError: division by zero
# print("Dalsza część programu")

try:
    # print(5/0)
    # print("A"+9)
    # print(int("A"))
    # raise KeyError("brak klucza")
    wynik=90/34
except ZeroDivisionError:
    print("Nie dziel przez zero")
except TypeError:
    print("błąd typu")
except ValueError:
    print("błąd wartości")
except Exception as e:
    print("błąd", e)
else:  # tylko gdy nie ma błędu
    print("wyniki", wynik)
finally:
    print("wykona się zawsze")


print("Dalsza część programu")
# Nie dziel przez zero
# Dalsza część programu
# błąd typu
# Dalsza część programu
# błąd wartości
# Dalsza część programu
# Dalsza część programu
# błąd 'brak klucza'
# Dalsza część programu
# błąd 'brak klucza'
# wykona się zawsze
# Dalsza część programu
# wyniki 2.6470588235294117
# wykona się zawsze
# Dalsza część programu



