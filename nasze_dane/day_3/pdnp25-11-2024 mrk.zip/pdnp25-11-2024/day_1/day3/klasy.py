# klasy to już nie tyko programowanie
# to inne podejście do tworzenia programu
# mogą mieć cechy i funkcje, ni eposługujmey się elementami tylko obiektem zbudowanym wg przepisu
# klasa ma wystaczyć standard, musi być zadeklarowana/zdefiniowanie
#budowanie obiektu klasy uruchamia metodę inicjalizującą
# 4 podsta paradygmaty: hermetyzacja, dziedziczneie, polimorfizm, abstrakcja
# po dwukropku przynajmniej 1 komenda/linijka


class Human:
    """
    klasa Human w pythonie
    """

    imie=""
    wiek=None
    plec="k"


print(Human.__doc__) # klasa Human w pythonie
cz1=Human()  # tworzenie obiektu klasy
print(cz1)  # <__main__.Human object at 0x00000289941D7CB0>
print(cz1.imie)
print(cz1.wiek)
print(cz1.plec)

cz1.imie="Anna"
cz1.wiek=27
print(cz1.imie)
print(cz1.wiek)
print(cz1.plec)
# Anna
# 27
# k

cz2=Human()
cz2.imie="Radaek"
cz2.wiek=45
cz2.plec="m"
print(cz2.imie)
print(cz2.wiek)
print(cz2.plec)
# Radaek
# 45
# m