# kolekcje
#  mogą przechowywać wilele elementów, różnego typu na raz
# Lista - przechowuje dowolna ilośc elelmentów, róznego rodzaju na raz
# zachowuje kolejność przy dodawaniu elementów

# pusta lista
lista = []
print(lista)  # []
print(type(lista))  # <class 'list'>

pusta_lista = list()
print(pusta_lista)  # []
print(type(pusta_lista))  # <class 'list'>

# dodawanie elementów do listy
lista.append("Radek")
lista.append("Grzegorz")
lista.append("Maciek")
lista.append("Marek")
lista.append("Zośka")
lista.append("Zenek")
lista.append("Dariusz")

print(lista)
# ['Radek', 'Grzegorz', 'Maciek', 'Marek', 'Zośka', 'Zenek', 'Dariusz']
#     0          1         2         3        4        5        6
#    -7          -6        -5       -4        -3       -2       -1
print(lista[0]) # Radek
print(lista[2]) # Maciek
print(lista[4]) # Zośka

print(len(lista))
# ctrl alt l - formatowanie zgodnie z PEP8

print(lista[len(lista)-1])  # Zenek
print(lista[-1])  # Zenek
print(lista[-3])  # Marek

# wyświetlanie fragmentu listy (slicowanie)
print(lista[3:5])  # imiona z nr ['Marek', 'Zośka'] bez 5 nie włącznie
print(lista[:5]) # pokazuje imiona z pozycji 01234 ['Radek', 'Grzegorz', 'Maciek', 'Marek', 'Zośka']
print(lista[2:]) # pokazuje imiona od pozycji 23456 ['Maciek', 'Marek', 'Zośka', 'Zenek', 'Dariusz']
print(lista[2:6]) # pokazuje imiona od pozycji 2345 ['Maciek', 'Marek', 'Zośka', 'Zenek'] bez 6 nie włącznie

print(lista[2:10]) # ['Maciek', 'Marek', 'Zośka', 'Zenek', 'Dariusz']
print(lista[10:20]) # [] pusta lists
print(lista[2:2]) # [] pusta lists
print(lista[2:3]) # ['Maciek']
print(lista[:]) # ['Radek', 'Grzegorz', 'Maciek', 'Marek', 'Zośka', 'Zenek', 'Dariusz']
# ['Radek', 'Grzegorz', 'Maciek', 'Marek', 'Zośka', 'Zenek', 'Dariusz']
#     0          1         2         3        4        5        6
#    -7          -6        -5       -4        -3       -2       -1
print(lista[-2:0])  # pusta lista [] indeksy nie zawijają się
print(lista[0:-2])  # ['Radek', 'Grzegorz', 'Maciek', 'Marek', 'Zośka'] bez -2 nie włącznie
print(lista[-6:-2])  #['Grzegorz', 'Maciek', 'Marek', 'Zośka']

print(lista[-1]) # Dariusz

lista_15=list(range(15))
print(lista_15) # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

print(list(range(0,15,2))) # [0, 2, 4, 6, 8, 10, 12, 14]

print(list(range(0,15,3))) # [0, 3, 6, 9, 12]

print(lista_15[-10]) # 5

#nadpisanie elementu
# zamiana imienia Marek na Mikołaj,
lista[3] = "Mikołaj"
print(lista) # ['Radek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Zośka', 'Zenek', 'Dariusz']

# dopisanie elementu we wskazanym indeksie i miejscu
lista.insert(1,"Marek")
print(lista)  # ['Radek', 'Marek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Zośka', 'Zenek', 'Dariusz']

# sprawdzenie indeksu dla elementu
print(lista.index("Zenek"))  # 6 pokazanie pozycji

# usunięcie elementu z listy
lista.append("Zenek")
print(lista) # ['Radek', 'Marek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Zośka', 'Zenek', 'Dariusz', 'Zenek']
print(lista.remove("Zenek")) # usuwa 1 element nei ten co wcześniej dodał na końcu ['Radek', 'Marek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Zośka', 'Zenek', 'Dariusz', 'Zenek']
print(lista) # ['Radek', 'Marek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Zośka', 'Dariusz', 'Zenek']

#usunięcie zlisty po indekxie i pokazanie co usunął
print(lista.pop(5))
print(lista) # ['Radek', 'Marek', 'Grzegorz', 'Maciek', 'Mikołaj', 'Dariusz', 'Zenek']

print(lista.pop(-2)) # usunięty Dariusz
print(lista.pop()) # usuń ost element Zenek (co wcześniej dodany)

lista.insert(5, "Zośka")
print(lista)
print(lista.pop(5))
lista.insert(2, "Zoska")
print(lista)

a=1
b=3
print(a,b) # 1 3
a=b
print(a,b) # 3 3
b=7
print(f"{a=},{b=}")  # a=3,b=7

lista_2 = lista #kopia adresu w pamięci, referencji
print(lista) # []
print(lista_2) #[]
lista_copy=lista.copy() # kopia elementów listy do nowej listy
lista.clear() # czyszczenie elementów listy
print(lista)
print(lista_2)
print(lista_copy) # ['Radek', 'Marek', 'Zoska', 'Grzegorz', 'Maciek', 'Mikołaj']

print(id(lista_2))
print(id(lista))
print(id(lista_copy))
# 2645177508416
# 2645177508416
# 2645181152960

liczby=[54,999,34,22,12,34,687]
print(liczby) # [54, 999, 34, 22, 12, 34, 687]
print(type(liczby)) # <class 'list'>

liczby.sort()
print(liczby) # [12, 22, 34, 34, 54, 687, 999]

liczby =[54,999,34,22,12,34,687,"A"]
print(type(liczby)) # <class 'list'>
# liczby.sort() # TypeError: '<' not supported between instances of 'str' and 'int'
# nie posortuje jak mieszane dane, liczby i tekst
lista_litery=["b","a","z","w"]
lista_litery.sort()
print(lista_litery) # ['a', 'b', 'w', 'z']

lista_litery.reverse()
print(lista_litery) # odwrócenie kolejności ['z', 'w', 'b', 'a']

# sortowanie z odwróceniem
lista_litery.sort(reverse=True)
print(lista_litery) # ['z', 'w', 'b', 'a']
print(lista_litery[::-1]) # ['a', 'b', 'w', 'z'] wyświetlenie listy w odwrotnej kolejności

liczby[3]=666
print(liczby[0:3]) # [54, 999, 34]
print(liczby[-2]) #687
print(liczby) # [54, 999, 34, 666, 12, 34, 687, 'A']
print(liczby.pop(2)) # 34
liczby.remove(54)
print(liczby)

del liczby
#print(liczby) # NameError: name 'liczby' is not defined

# rozpakowanie sekwencji
tekst="Pyt hon."
lista1=list(tekst)
print(lista1)  # ['P', 'y', 't', ' ', 'h', 'o', 'n', '.']

lista2=[tekst]
print(lista2)  # ['Pyt hon.']

# krotek nie można modyfikować, są podobne do listy, tworzymy za pomocą nawiasów () a listy w []
# tyko do odczytu
# kolekcja niemutowalna pozwala lepiej zarządzać pamięcią
# krotka jednoelementowa - stała - może być traktowana jako zmienna
krotka = tuple(lista_litery)
print(krotka) # ('z', 'w', 'b', 'a')
print(type(krotka)) # <class 'tuple'>










