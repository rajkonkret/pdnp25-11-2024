# zbiór (set) - przechowuje unikalen wartości
# nie zachowuje kolejności przy dodawaniu elementów
# nie ma indeksu

lista=[44,55,66,777,33,22,11,33,11]
zbior=set(lista) # zmiana na zbiór, set
print(type(zbior)) # <class 'set'>
print(zbior) # {33, 66, 777, 11, 44, 22, 55}

# utworzenie pustego zbioru
zb2=set()
print(zb2) # set()

# dodanie elementu do zbioru
zbior.add(33)
zbior.add(123)
zbior.add(33)
zbior.add(33)
zbior.add(33)
zbior.add(18)
zbior.add(18)
zbior.add(24)
print(zbior) # {33, 66, 777, 11, 44, 18, 22, 55, 24, 123}

# usunięcie elementu
zbior.remove(55)
print(zbior) # {33, 66, 777, 11, 44, 18, 22, 24, 123}

# pop() # usuwa pierwszy ze zbioru
print(zbior.pop()) # 33
print(zbior) # bez 33: {66, 777, 11, 44, 18, 22, 24, 123}

zbior_copy=zbior.copy()
print(zbior) # {66, 777, 11, 44, 18, 22, 24, 123}
print(zbior_copy) # {66, 777, 11, 44, 18, 22, 24, 123}
print(id(zbior))  # 1964795434528
print(id(zbior_copy)) # 1964795760864

zbior_2={667,11,44,18,52,62,999,999,12.34}
print(type(zbior_2)) # <class 'set'>
print(zbior_2) # {999, 11, 44, 12.34, 18, 52, 667, 62}


# suma zbiorów -tworzy nowy zbiór ze wszytkich elem 1 i 2 zbioru, nie sumuje zawartości
print(zbior | zbior_2)  # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 123, 667, 62}
print(zbior.union(zbior_2)) # to samo jak wyżej komendą: {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 123, 667, 62}

# część wspólna
print(zbior&zbior_2)  # {18, 11, 44}
print(zbior.intersection(zbior_2)) # to samo komnendą {18, 11, 44}

# różnica
print(zbior-zbior_2) # elem które się nie powtarzają {66, 777, 22, 24, 123}
print(zbior.difference(zbior_2)) # {66, 777, 22, 24, 123}
print(zbior_2.difference(zbior)) # {999, 12.34, 52, 667, 62}

# modyfikuje zbior bazowy
zbior.update(zbior_2)
print(zbior)  # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 123, 667, 62}

print(999 in zbior)

# zbiór nie ma indekstu tak jak krotka - zwraca listę,  nie posortuje

print(sorted(zbior)) #zwraca listę, nie zmieni zbioru: [11, 12.34, 18, 22, 24, 44, 52, 62, 66, 123, 667, 777, 999]
print(zbior) # zbór jest be zmian: {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 123, 667, 62}





