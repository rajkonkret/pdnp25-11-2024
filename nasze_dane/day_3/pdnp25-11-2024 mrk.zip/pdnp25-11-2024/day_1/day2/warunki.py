# warunki - instrukcje warunkowe
# instrukcje sterowania programu


odp=True
print(bool(odp))
odp=False
if odp:
    # obowiązkowe 4 spacje
    # wykona się gdy warunek spełniony
    print("brawo")
    print("brawo")
    print("brawo")
#  print("brawo")  # błąd wcięcia IndentationError: unindent does not match any outer indentation level

print("dalsza część programu")
odp="Radek"
print(bool(odp)) # True
print(odp=="Radek") # dwa == to równianie
if odp=="Tomek":
    print('tojest Tomek')
else: # w przeciwnym wypadku
    print('to nie jest Tomek') # to nie jest Tomek

# podatek=0
# zarobki=int(input("podaj zarobki"))
# if zarobki<10_000:
#     podatek = 0
# elif zarobki >30_000: #kolejny if
#     podatek=0.4
# elif zarobki< 30_000:
#     podatek=0.2
# else:
#     podatek = 0.9

#print("podatek wynosi", podatek*zarobki)

# napisać apliakcję test
# zadać pytanie
# pobrać odpo od użytkownika
# wypisać wynika zdał nie zdał

# punkty=0
# odp=input("podaj rok bitwy pod Grunwaldem") # str
# if odp.strip()== '1410':  # strip usuwa spacje /białe znaiki
#     print("zdałeś")
#     punkty+=1  # punkty=punkty+1
# else:
#     print("musisz uczyć się dalej")
# print(f"Zdobyłeś {punkty} punkty.")

suma_zam=150
if suma_zam>100:
    rabacik=25
else:
    rabacik=0

print(f"Rabat wynosi {rabacik}")
#ctrl / - komentarz

rabat=25 if suma_zam>100 else 0
print(f"Rabat wynosi {rabat}")

rabat=25 if suma_zam>100 else 0
print(f"Rabat wynosi {rabat}") # rabat wynosi 25

if odp == "Radek":
    if suma_zam > 50:
        rabat = 200

print(f"Rabat wynosi {rabat}")
