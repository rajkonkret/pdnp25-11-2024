# słownik - dane typu para klucz-wartość
# {"user':"Radek,"wiek":78}
#"klucz":"wartość"}
# json służy do komunikacji między serwerami i python tłumaczy sobie w słowniku
#klucze nie mogą się powtarzać

#pusty słownik
dictionary_1={}
print(dictionary_1) # {}
print(type(dictionary_1)) # <class 'dict'>

#dodawanie elementów do słownika
dictionary={}
dictionary["imie"]="Radek"
print(dictionary) # {'imie': 'Radek'}
(dictionary)["wiek"]="45"
print(dictionary) # {'imie': 'Radek', 'wiek': '45'}

# nadpisanie elementu
dictionary['imie']="Tomek"
print(dictionary) # {'imie': 'Tomek', 'wiek': '45'}

print(dictionary.keys())
print(dictionary.values())
print(dictionary.items())
# dict_keys(['imie', 'wiek'])
# dict_values(['Tomek', '45'])
# dict_items([('imie', 'Tomek'), ('wiek', '45')])

# wypisanie elementu ze słownika
print(dictionary.get("Imie")) # none gdy nie ma klucza
# print(dictionary("Imie")) # TypeError: 'dict' object is not callable
print(dictionary.get("Imie", 'default')) # default -jak nie ma wartości/klucza w słowniku bo z wielkiej a w słowniku z małej

dictionary.update({"date":"12-12-2024"})
print(dictionary) # {'imie': 'Tomek', 'wiek': '45', 'date': '12-12-2024'}

dict_small={"x":2}
dict_small.update([('y',3),("z",7)])
print(dict_small) # {'x': 2, 'y': 3, 'z': 7}

# input()- pobiera dane od użytkownika
# tekst=input("Podaj imię")
# print(tekst)
# print(type(tekst))

# napisać aplikację kalkulator
# pobrać dwie liczby ->2xinput
# wypisać wynik dodawanie ->print

# prosty kalkulator w P
#num1=input('podaj pierwszą liczbę')
#num2=input('podaj drugą liczbę')
#wybór operatora
#choice=input('wybierz operator(+=dodawanie,-=odejmowanie,*=mnożenie,/=dzielenie): ')
# a=int(input("podaj 1 l"))
# b=input("podaj 2 l")
# print(a+float(b))

# napisz aplikację pol-ang
# słownik ze słówkami i tłumaczeniami
# pobrać o co pyta > input
# wyświetlić tłumaczenie > czyli wartość klucza

slownik={"pies":"dog","pon":"monday","dach":"roof"}
#slownik.update([("samochód":"car"),("dom":"house")])
print("mamy takie słówka", slownik.keys())
odp=input("podaj slowowo: ")
print(slownik[odp])
# print(f'tłumaczenie{odp}:{slownik.get(odp.casefold().strip(),"nie ma")}')




