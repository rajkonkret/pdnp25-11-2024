# komentarz
# PEP8 -  zasady formatowania kodu
import sys

print()  # wypisz/wydrukuj

print("Nazywam się Magda")
print("Nazywam się Magda")
print("Nazywam się Magda")
print("Nazywam się Magda")
print("Nazywam się Magda")
print("Nazywam się Magda")
# ctrl d powielania linii
# Nazywam się Magda
# Nazywam się Magda
# Nazywam się Magda
# Nazywam się Magda
# ctrl / - kompetarz zaznaczonego fragmentu
# komentarz
# print('Magda")
# celowy błąd

print(39)
print(type(30))  # <class 'int', integer, liczby całkowiete

# print(39 + 39) #78

print(5 * "4") # 44444
print(160 * 35)
print("160" * 35)
# 5600
# 160160160160...

# zmienna - pudełko na dane
liczba =  39
print(type(liczba))

name: str = "Magda"
print(name)
print(type(name))

name = 90
print(name)
print(type(name))

age = 38
print(age)
print(type(age))

print(sys.int_info)
# ALT f7 - pokazuje uzycie danej funkcji

# sys.int_info(
#