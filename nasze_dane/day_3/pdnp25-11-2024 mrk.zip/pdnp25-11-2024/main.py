# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
# ctrl shift f10

# uruchamianie programu w pythonie z linii komend
# (.venv) PS C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024> python.exe .\main.py
# Hi, PyCharm
# (.venv) PS C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024>
# (.venv) PS C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024> python main.py
# Hi, PyCharm
# (.venv) PS C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024>
# 2 x shift
# wheel - zmożliwośc zmiany wielkości tekstu kółkiem myszy
