tekst = "Witaj Świecie"
print(tekst)
print(type(tekst))
# Witaj Świecie
# <class "str">

# wszystko jest obiektem
tekst.upper()  #nie zmienia prginalnego
print(tekst.upper()) # WITAJ ŚWIECIE
print(tekst)

print(tekst.lower())

print(tekst.count("i"))
print(tekst.count("j",0,4))

tekst_zamiana = "Witaj dobry Świecie"
print(tekst_zamiana.replace("dobry",""))
#strip()
print(tekst.removeprefix("Witaj"))  #"Świecie
print(tekst.removeprefix("Witaj").strip())  #Świecie"

encode_s = tekst.encode("utf-8")
print(encode_s)  # b'Witaj \xc5\x9awiecie'
print(type(encode_s))  # <class 'bytes'>

print(encode_s.decode('utf-8'))  # Witaj Świecie

imie = "Mariusz"
tekst_format = f"Mam na imię {imie} i lubię pythona"
print(tekst_format)
tekst_format = f"\tMam na imię {imie}\n i lubię pythona\b"
print(tekst_format)

starszy = "Witaj %s"  # %s - string
print(starszy % imie)  # Witaj Mariusz

print("Witaj {}".format(imie))

print ("Witaj", imie)

print("""
Tekst
    wielolinijkowy
    """)
