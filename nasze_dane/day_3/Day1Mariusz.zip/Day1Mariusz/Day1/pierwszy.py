# komentarz
# PEP8 - zasady formatowania kodu
# ctrl alt l

import sys

print ()  #wypisz/wydrukuj
print ("Mam na imię Mariusz")
print ("Mam na imię Mariusz")
print ("Mam na imię Mariusz")
print ("Mam na imię Mariusz")
# ctrl d powielanie linii
#ctrl / komentarz zaznaczonego obiektu

print (""'Mariusz'"")
print (39)
print (39+39)
print(int("39")+39)  #  rzutowanie na int
print("39"+str(39)) #  rzutowanie na tekst

print(5 * "4")  #44444

# zmienna - pudełko na dane
# nazwy zmiennych z małej litery
# snake_case
# nazwa zmiennej powinna wskazywać co przechowuje

name: str = "Mariusz"
print(name)
print(type(name))
# Mariusz
# <class 'str">
name = 90
print(name)
(print(type(name)))
# 90
# <class "int">

age = 39
print(age)
print(type(age))

print(sys.int_info)
# ALT F7 - pokazuje uzycie danej funkcji