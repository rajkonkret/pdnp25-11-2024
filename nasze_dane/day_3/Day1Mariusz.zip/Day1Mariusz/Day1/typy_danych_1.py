import sys

wiek = 47
rok = 2024
temp = 36.6

print(temp)
print(type(temp))

print(wiek + rok)
print(wiek - rok)
print(wiek * rok)
print(wiek / rok)

print(rok // wiek)
print(rok % wiek)
print(10 % 3)
print(wiek ** rok)

print(len(str(wiek ** rok)))
print(1 / 3)

print(54 - 5 * 43 + 8 / 2 + 8 / 2)
print(54 - 5 * 43 + (8 / 2 + 8) / 2)

print(0.2 + 0.8)
print(0.2 + 0.7)
print(0.1 + 0.2)

print(sys.float_info)

print(f"Sprawdzenie zmiennej {temp} {wiek}")

czy_znasz_pythona = True
print(czy_znasz_pythona)
print(type(czy_znasz_pythona))

print(int(True))
print(int(False))

print(bool(1))
print(bool(0))

print(bool(100))
print(bool(-10))
print(bool("Mariusz"))

print(bool(0))
print(bool(""))
print(bool(None))

print(True and False)
print(True and True)






