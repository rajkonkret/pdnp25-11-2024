# funkcja lambda
# skrócony zapis funkcji
# lambda zawsze zwraca wynik
# funkcja anonimowa

def odejmij(a, b):
    return a - b


print(odejmij(45, 90))  # -45
odejmij2 = lambda a, b: a - b
print(odejmij2(45, 78))  # -33

wiek = lambda x: "dziecko" if x < 10 else ("nastolatek" if x < 18 else "dorosły")

print(wiek(9))
print(wiek(10))
print(wiek(17))
print(wiek(18))
print(wiek(25))

lista = [1, 2, 3, 10, 20, 30, 100, 200, 500]

print([i *2 for i in lista])

lista_wyn = []
def zmien(x):
    return x*2

for i in lista:
    lista_wyn.append(zmien(i))
print(lista_wyn) # [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# map() mapowanie danych, zmiana danych wh zadanej funkcji
print(f"zastosowanie map() {list(map(zmien, lista))}") #zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# lambda jako funkcja anonimowa - wykonanie w miejscu deklaracji

print(f"zastosowanie map() {list(map(lambda x: x*2, lista))}")
print(f"zastosowanie map() {list(map(lambda x: x*4, lista))}")
print(f"zastosowanie map() {list(map(lambda x: x*5, lista))}")
print(f"zastosowanie map() {list(map(lambda x: x*12, lista))}")
print(f"zastosowanie map() {list(map(lambda x: x*2, lista))}")
# zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]
# zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]
# zastosowanie map() [4, 8, 12, 40, 80, 120, 400, 800, 2000]
# zastosowanie map() [5, 10, 15, 50, 100, 150, 500, 1000, 2500]
# zastosowanie map() [12, 24, 36, 120, 240, 360, 1200, 2400, 6000]
# zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# filtrowanie danych
#filter() - zwraca elementy spełniające warunek zadany funkcją
# funkcje wyższego rzędu
print(f"Zastosowanie filter {list(filter(lambda x: x<3, lista))}") #Zastosowanie filter [1, 2]
print(f"Zastosowanie filter {list(filter(lambda x: x>20, lista))}") #Zastosowanie filter [30, 100, 200, 500]
print(f"Zastosowanie filter {list(filter(lambda x: x>20 and x<200, lista))}") #Zastosowanie filter [[30, 100]
print(f"Zastosowanie filter {list(filter(lambda x: 20 < x < 200, lista))}") #Zastosowanie filter [30, 100]

