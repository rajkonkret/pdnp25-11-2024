# wyjątki - błędy generowane przez działanie programu

# print(5 / 0)
# print("Dalsza część programu")

try:
    # print(5 / 0)
    print("A" + 9)
    wynik = 90 / 34
except ZeroDivisionError:
    print("Nie dziel przez zero")
except TypeError:
    print("Błąd typu")
except ValueError:
    print("Błąd wartości")
except Exception as e:
    print("Błąd", e)
else: #tylko gdy nie ma błędu
    print("Wynik", wynik)
finally:
    print("Wykona się zawsze")
print("Dalsza część programu" )



