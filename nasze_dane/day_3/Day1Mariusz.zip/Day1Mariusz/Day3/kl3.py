from abc import ABC, abstractmethod


class Ptak(ABC):
    """
    Klasa opisująca Ptaka w pythonie
    """

    def __init__(self, gatunek, szybkosc):
        """
        Metoda inicjalizująca (konstruktor)
        :param gatunek:
        :param szybkosc:
        """

        self.gatunek = gatunek
        self.szybkosc = szybkosc

    def latam(self):
        print("Tu", self.gatunek, "Lecę z szybkością", self.szybkosc)

    @abstractmethod
    def wydaj_odglos(self):
        pass


class Kura(Ptak): #"Kura dziedziczy po klasie Ptak"
    """Klasa Kura"""

    def __init__(self, gatunek):
        super().__init__(gatunek,0)

    def latam(self):
        print("Tu", self.gatunek, "Ja nie latam")


    def wydaj_odglos(self):
        print("ko ko ko ko")

class Orzel(Ptak):
    def wydaj_odglos(self):
        print("kir kir kir")


# or1 = Ptak("Orzel", 45)
# or1.latam()
# kur1 = Ptak("Kura", 0)
# kur1.latam()

kur2 = Kura("Kura domowa")
kur2.latam()
or2 = Orzel("Orzeł bielik", 45)
or2.latam()

lista = (or2, kur2)
for i in lista:
    i.wydaj_odglos()
