# klasa - szablon, przepis
# cechy i funkcje
# obiekt - zbudowany wg przepisu
# klasa musi być najpierw zadeklarowana
# budowanie obiektu klasy uruchamia metodę inicjakizującą
# hermetyzacja, dziedziczenie, polimorfizm, abstrakcja


class Human:
    """
    Klasa Human w pythonie
    """

    imie = ""
    wiek = None
    plec = "k"


print(Human, __doc__)
cz1 = Human()
print(cz1)
print(cz1.imie)  # Anna
print(cz1.wiek)  # 27
print(cz1.plec)  # k

cz1.imie = "Anna"
cz1.wiek = 27
print(cz1.imie)
print(cz1.wiek)
print(cz1.plec)

cz2 = Human()
cz2.imie = "Mariusz"
cz2.wiek = 39
cz2.plec = "m"

print(cz2.imie)  # Mariusz
print(cz2.wiek)  # 39
print(cz2.plec)  # m
