# pętle - możliwość wykonania tego samego kodu wielokrotnie
# for - pętla iteracyjna
import random # do działań pseudolosowych
for i in range(5): # od 0 do 4
    print(i)
# 0
# 1
# 2
# 3
# 4
for i in range(1000):
    pass #nic nie robi

for _ in range(10): #niema zmienna
    print("To jest pętla")

print(random.randint(1,100)) # od 1 do 100
print(random.randrange(1,100)) # od 1 do 99
print(random.randrange(6)) # od 0 do 5
print(random.random()) #float od 0 do 0,99999999

lista = [67,45,32,68,89,90,42]
print(random.choice(lista)) # 67

lista_kule = list(range(1,50))
print(lista_kule)

lista_wylosowana = []
for _ in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)

print(lista_wylosowana) #[38, 17, 4, 44, 30, 8]

print(random.choices(lista_kule, k=6)) #losuje z powtórzeniami [14, 3, 24, 33, 4, 2]
print(random.sample(lista_kule, k=6)) #[39, 15, 11, 25, 7, 45] losuje unikalne

for i in range(10):
    if i % 2 == 0:
        print(i, "parzysta")
# 0 parzysta
# 2 parzysta
# 4 parzysta
# 6 parzysta
# 8 parzysta

lista3 = [j for j in range(10) if j % 2 ==0]
print(lista3) # [0, 2, 4, 6, 8]

for c in lista_wylosowana:
    if c >10:
        print("Większe od 10")
    else:
        print("Mniejsze lub równe od 10")

# Większe od 10
# Większe od 10
# Większe od 10
# Mniejsze lub równe od 10
# Większe od 10
# Większe od 10

dictionary = {"imię":"Mariusz", "nazwisko":"Szewczyk"} #słownik

for i in dictionary:
    print(i)
# imię
# nazwisko
for k in dictionary.keys():
    print(k)
# imię
# nazwisko

for v in dictionary.values():
    print(v)
# Mariusz
# Szewczyk

for i in dictionary.items():
    print(i)
# ('imię', 'Mariusz')
# ('nazwisko', 'Szewczyk')

for k,v in dictionary.items():
    print(k, "=>", v)
# imię = > Mariusz
# nazwisko = > Szewczyk


