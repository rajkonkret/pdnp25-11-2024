# while - pętla sterowana warunkiem

# pętla nieskończona
# while True:
#     print("komunikat")

licznik = 0
while True:
    licznik += 1  # licznik = licznik +1
    print("komunikat2 !!!")
    if licznik > 10:
        break  # przerwanie pętli

print(licznik)  # 11

licznik = 0
while licznik < 10:
    licznik += 1
    print("Komunikat 3 !!!")

lista = []
lista_int = []
while True:
    wej = input("Podaj liczbę")
    if not wej.isnumeric():
        break
    lista.append(wej)
    lista_int.append(int(wej))

    print(lista)  # ['34', '34', '34']
    print(lista_int)  # [34, 34, 34]

print(lista)

my_list = [1, 5, 2, 3, 5, 4, 5, 6, 5]
print(5 in my_list)
while 5 in my_list:
    my_list.remove(5)

print(my_list)
