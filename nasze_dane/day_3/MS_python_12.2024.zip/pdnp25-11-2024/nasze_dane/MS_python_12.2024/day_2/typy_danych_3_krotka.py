krotka = "Radek"
print(type(krotka))

print(krotka)

krotka1 = ("Radek")
print(type(krotka1))

print(krotka1)

krotka2 = "Radek",
print(type(krotka2))

print(krotka2)

krotka3 = ("Radek",)
print(type(krotka3))

print(krotka3)

krotka_liczby = 43, 55, 22.34, 11, 200
print(type(krotka_liczby))
print(krotka_liczby)

krotka_imiona = "Radek", "Tomek", "Zenek", "Marcin", "Jacek", "Ania", "Zosia"
print(krotka_imiona)
print(type(krotka_imiona))

print(krotka_imiona.index("Radek"))
print(krotka_imiona.count("Radek"))

print(len(krotka_imiona))

print(sorted(krotka_imiona))
print(krotka_imiona)

lista = sorted(krotka_imiona)
print(lista)
print(type(lista))

tup = 1, 2
a, b = 1, 2
print(a, b)

a, b = tup
print(a, b)

a, *b = krotka_imiona

print(a, b)

print(type(a))
print(type(b))

name1, name2, *name3 = krotka_imiona
print(name1, name2, name3)

name1, *name2, name3 = krotka_imiona
print(name1, name2, name3)

*name1, name2, name3 = krotka_imiona
print(name1, name2, name3)

lista=list(krotka_liczby)
print(lista)

print(200 in lista)