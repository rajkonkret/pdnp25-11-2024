#instrukcje warunkowe

odp = True
print(bool(odp))
if odp:
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")
    print("Brawo")

print("Dalsza część programu")

odp = "Radek"
print(bool(odp))

if odp == "Radek":
    print("Radek")

if odp == "Tomek":
    print("To jest Tomek")
else:
    print("To nie jest Tomek")

# podatek = 0
# zarobki = int(input("Podaj zarobki"))
# if zarobki < 10000:
#     podatek = 0
# elif zarobki < 30000:
#     podatek = 0.2
# elif zarobki < 100000:
#     podatek = 0.4
# else:
#     podatek = 0.9
#
# print("Podatek wynosi", podatek * zarobki)

suma_zam = 150
if suma_zam > 100:
    rabacik = 25
else:
    rabacik = 0

print(f"Rabat wynosi {rabacik}")

rabat = 25 if suma_zam > 100 else 0
print(f"Rabat wynosi {rabat}")

if odp == "Radek":
    if suma_zam >50:
        rabat = 200

print(f"Rabat wynosi {rabat}")