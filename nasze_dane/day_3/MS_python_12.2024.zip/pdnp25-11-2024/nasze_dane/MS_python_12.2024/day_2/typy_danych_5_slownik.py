# słownik -> dane typu para: klucz-wartość

dictionary = dict()
print(dictionary)

dictionary_1 = {}
print(dictionary_1)
print(type(dictionary_1))

dictionary["imie"] = "Radek"
print(dictionary)

dictionary["wiek"] = "45"
print(dictionary)

dictionary["imie"] = "Tomek"
print(dictionary)

print(dictionary.keys())
print(dictionary.values())
print(dictionary.items())

print(dictionary["imie"])
print(dictionary["wiek"])

print(dictionary.get("Imie"))
print(dictionary.get("Imie", "nie ma"))

dictionary.update({"date": "2024-12-12"})
print(dictionary)

dict_small = {"x": 2}
dict_small.update([("y", 3), ("z", 7)])
print(dict_small)

# input

# tekst = input("Podaj imię:")
# print(tekst)

# kalkulator

# liczba_1 = input("Podaj 1 liczbę:")
# liczba_2 = input("Podaj 2 liczbę:")

# a = float(liczba_1)
# b = float(liczba_2)

# print("Wynik sumy:", a + b)


# print("Wprowadź słowa do słownika!")
# slownik = {}
# slo_pol = input("Wstaw polskie słowo: ")
# slo_eng = input("Wstaw angielskie słowo: ")

# slownik[slo_pol] = slo_eng
# print(slownik)

pol_ang = {'poniedziałek':'monday', 'wtorek':'tuesday', 'środa':'wednesday'}
print("Mamy takie słówka", pol_ang.keys())
odp = input("Podaj słówko do przetłumaczenia: ")
# print(pol_ang[odp.casefold()])
print(f'Tłumaczenie {odp} : {pol_ang.get(odp.casefold().strip()), "Nie ma"}')
