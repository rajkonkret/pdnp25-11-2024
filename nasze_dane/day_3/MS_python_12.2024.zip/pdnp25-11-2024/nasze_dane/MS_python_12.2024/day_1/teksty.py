tekst = "Witaj Świecie"

print(tekst)
print(type(tekst))

tekst_upper = tekst.upper()

print(tekst.upper())
print(tekst_upper)

tekst_lower = tekst.lower()

print(tekst.lower())
print(tekst_lower)

print(tekst.count("i"))

print(tekst.count("j", 0, 4))

print(tekst.find("e"))

tekst_zmiana = "Witaj dobry świecie"

print(tekst_zmiana.replace("dobry",""))

encode_s = tekst.encode('utf-8')

print(encode_s)
print(type(encode_s))
print(encode_s.decode('utf-8'))

imie = "Michał"

tekst_format = f"Mam na imię {imie} i lubię pythona."
print(tekst_format)

tekst_format = f"\tMam  na imię {imie}\n i lubię pythona.\b"
print(tekst_format)

print("Witaj", imie)

print("""
Tekst
    wielolinijkowy
""")

