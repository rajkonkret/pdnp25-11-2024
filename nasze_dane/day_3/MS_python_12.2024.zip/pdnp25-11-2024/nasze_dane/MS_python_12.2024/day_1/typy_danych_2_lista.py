lista = []
print(lista)
print(type(lista))

pusta_lista = list()
print(pusta_lista)
print(type(pusta_lista))

lista.append("Radek")
lista.append("Grzegorz")
lista.append("Maciek")
lista.append("Marek")
lista.append("Zośka")
lista.append("Zenek")
lista.append("Dariusz")

print(lista)

print(lista[0])
print(lista[1])
print(lista[2])
print(lista[3])
print(lista[4])
print(lista[5])
print(lista[6])

print(len(lista))

print(lista[len(lista) - 1])
print(lista[-1])
print(lista[-2])
print(lista[-3])
print(lista[-4])
print(lista[-5])
print(lista[-6])
print(lista[-7])

print(lista[0:3])
print(lista[:3])
print(lista[3:])
print(lista[10:])
print(lista[3:9999])
print(lista[-2:-7])
print(lista[-7:-2])
print(lista[:])
print(lista[3:0])
print(lista[-2:0])

lista_15 = list(range(15))
print(lista_15)
print(lista_15[0:15:2])

print(list(range(0, 15, 2)))

lista[3] = "Mikołaj"
print(lista)

lista.insert(1, "Marek")
print(lista)

print(lista.index("Zenek"))

lista.append("Zenek")
print(lista)

print(lista.remove("Zenek"))

lista.remove("Zenek")
print(lista)

print(lista.pop(5))
print(lista.pop(-2))
print(lista.pop())

print(lista)

a = 1
b = 3

print(a, b)

a = b

print(a, b)

b = 7

print(f"{a=},{b=}")

lista_2 = lista
lista_copy = lista.copy()

lista.clear()

print(lista)
print(lista_2)
print(lista_copy)

print(id(lista))
print(id(lista_2))
print(id(lista_copy))

x = "X"
y = "Y"

print(x,y)

x = y

print(x,y)

y = "Z"

print(x,y)

liczby = [54, 999, 34, 22, 12.34, 687]

liczby.sort()

print(liczby)

litery = ["a", 'z', "w", 'b']

litery.sort()

print(litery)

litery.reverse()

print(litery)

litery.sort(reverse=True)

print(litery)
print(litery[::-1])

liczby[3] = 666
print(liczby[0:3])
print(liczby[-2])
print(liczby)

print(liczby.pop(2))
liczby.remove(666)
print(liczby)

del liczby

# print(liczby)

tekst = "Pyt hon."
lista1 = list(tekst)

print(lista1)

lista2 = [tekst]
print(lista2)

krotka = tuple(litery)
print(krotka)
print(type(krotka))