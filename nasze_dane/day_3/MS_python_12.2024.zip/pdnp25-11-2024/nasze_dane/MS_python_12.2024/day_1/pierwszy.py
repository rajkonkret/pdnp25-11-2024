import sys

# Komentarz:
# PEP 8 - zasady formatowania kodu
# CTRL + ALT + L

print()  # wypisz/wydrukuj - pusta linia

print('My name is "Salineusz" ')

# CTRL + D -> powielanie danej linii

# My name is Salineusz
# My name is Salineusz
# My name is Salineusz
# My name is Salineusz
# My name is Salineusz
# My name is Salineusz

# CTRL + / -> dodaje #

print("39" + "39") # 3939, konkatenacja

# print("39" + 39) -> Process finished with exit code 1

print(int("39") + 39)

print("39" + str(39))

print(5 * "4")

name: str = "Radek"

print(name)
print(type(name))

name = 90

print(name)
print(type(name))

print(sys.int_info)
