# pętle

import random

for i in range(5):
    print(i)

for i in range(1000):
    pass

for _ in range(10):
    print("To jest pętla")

print(random.randint(1,100))
print(random.randrange(1,100))
print(random.randrange(6))
print(random.random())

lista = [67, 45, 32, 68, 89, 90, 42]

print(random.choice(lista))

lista_kule = list(range(1, 50))
print(lista_kule)

lista_wylosowana = []

for _ in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)

print(lista_wylosowana)

print(random.choices(lista_kule, k=6))
print(random.sample(lista_kule, k=6))

for i in range(10):
    if i % 2 == 0:
        print(i, "Parzysta")

lista_3 = [x for x in range(10) if x % 2 == 0]
print(lista_3)

for c in lista_wylosowana:
    if c > 10:
        print("Większe od 10")
    else:
        print("Mniejsze od lub równe 10")

dictionary = {'imie': "Radek", 'nazwisko': "Kowalski"}

for i in dictionary:
    print(i)

for k in dictionary.keys():
    print(k)

for l in dictionary.values():
    print(l)

for m in dictionary.items():
    print(m)

for k, v in dictionary.items():
    print(k, "=>", v)