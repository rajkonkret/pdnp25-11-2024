# while

# while True:
#    print("Komunikat!!!")

licznik = 0
while True:
    licznik += 1
    print("Komunikat 2!!!")
    if licznik > 10:
        break

print(licznik)

licznik = 0
while licznik < 10:
    licznik += 1
    print("Komunikat 3!!!")

print(licznik)

lista = []
lista_int = []

# while True:
#     wej = input("Podaj liczbę: ")
#     if not wej.isnumeric():
#         break
#     lista.append(wej)
#     lista_int.append(int(wej))
#
# print(lista)
# print(lista_int)

my_list = [1, 5, 2, 4, 5, 6, 5, 6, 5]

print(5 in my_list)
while 5 in my_list:
    my_list.remove(5)

print(my_list)
