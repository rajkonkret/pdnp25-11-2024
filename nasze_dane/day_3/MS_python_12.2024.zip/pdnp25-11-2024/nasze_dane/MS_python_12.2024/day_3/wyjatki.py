# wyjątki


try:
#    print(5 / 0)
#    print("A" + 9)
#    print(int("A"))

    wynik = 90/34

except Exception as e:
    print("Błąd", e)

else:
    print("Wynik:", wynik)

finally:
    print("Wykona się zawsze")