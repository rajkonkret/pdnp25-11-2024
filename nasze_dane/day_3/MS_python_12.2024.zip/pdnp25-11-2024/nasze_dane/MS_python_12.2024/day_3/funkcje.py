# funkcje

a = 8
b = 6
c = 10


def dodaj():
    print(a + b)


def dodaj_2(a, b):
    print(a + b)


def odejmij(a, b, c=0):
    print(a - b - c)


odejmij(3, 4, 2)
odejmij(5, 6)

odejmij(b=4, a=5)
odejmij(1, c=10, b=15)


def dodaj_3(a, b):
    return a + b


print(dodaj_3(4, 7))
wyn = dodaj_3(5, 8)
print("Wynik:",wyn)
print(dodaj_3(3,5) + dodaj_3(4,5))
