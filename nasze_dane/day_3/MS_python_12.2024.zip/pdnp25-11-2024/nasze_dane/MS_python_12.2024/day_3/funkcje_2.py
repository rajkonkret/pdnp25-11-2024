a = 10
b = 10


def dodaj():
    a = 7
    b = 8
    print(a + b)


def dodaj_2():
    global a
    a = 9
    b = 89
    print(a + b)


def dodaj_3():
    print(a + b)


print(f"Wartość a z góry {a=} {b=} (globalne)")
dodaj()
print(f"Wartość a z góry {a=} {b=} (globalne)")
dodaj_3()
dodaj_2()
print(f"Wartość a z góry {a=} {b=} (globalne)")
dodaj_3()