from abc import ABC, abstractmethod

class Ptak(ABC):
    """
    Klasa opisująca Ptaka w pythonie
    """

    def __init__(self, gatunek, szybkosc):
        """
        Metoda inicjalizująca (konstruktor)
        :param gatunek:
        :param szybkosc:
        """

        self.gatunek = gatunek
        self.szybkosc = szybkosc

    def latam(self):
        print("Tu", self.gatunek, ". Lecę z szybkością", self.szybkosc, ".")

    @abstractmethod #metoda abstrakcyjna

class Kura(Ptak):
    """
    Klasa Kura
    """

    def __init__(self, gatunek):
        super().__init__(gatunek,0)


    def latam(self):
        print("Tu", self.gatunek, ". Ja nie latam.")

    def wydaj odgłos(self):
        print("ko ko ko")


or1 = Ptak("Orzeł", 45)

kur1 = Ptak("Kura", 0)

kur2 = Kura("Kura domowa")

or1.latam()
kur1.latam()
kur2.latam()