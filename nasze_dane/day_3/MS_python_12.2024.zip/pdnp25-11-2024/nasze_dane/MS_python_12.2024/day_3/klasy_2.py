class Human:
    """
    Klasa Human
    """

    def __init__(self, imie, wiek, wzrost, plec="k"):
        """
        :param imie:
        :param wiek:
        :param wzrost:
        :param plec:
        """
        self.imie = imie
        self.wiek = wiek
        self.wzrost = wzrost
        self.plec = plec

    def powitanie(self):
        print("Mam na imię", self.imie)


cz1 = Human("Anna", 27, 168)

print(cz1.imie)
print(cz1.wiek)
print(cz1.wzrost)
print(cz1.plec)

cz2 = Human("Michał", 44, 188, "m")

print(cz2.imie)
print(cz2.wiek)
print(cz2.wzrost)
print(cz2.plec)

cz1.powitanie()
cz2.powitanie()

lista = [cz1, cz2]
for i in lista:
    i.powitanie()