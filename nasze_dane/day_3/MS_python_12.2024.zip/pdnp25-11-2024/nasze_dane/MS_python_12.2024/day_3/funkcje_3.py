# funkcja lambda

def odejmij(a, b):
    return a - b


print(odejmij(45, 90))
odejmij_2 = lambda a, b: a - b
print(odejmij_2(45, 78))


wiek = lambda x: "dziecko" if x < 10 else ("nastolatek" if x < 18 else "dorosły")

print(wiek(9))
print(wiek(10))
print(wiek(15))
print(wiek(18))
print(wiek(30))

lista = [1, 2, 3, 10, 20, 30, 100, 200, 500]

print([i * 2 for i in lista])


lista_wyn = []


def zmien(x):
    return x * 2


for i in lista:
    lista_wyn.append(zmien(i))
print(lista_wyn)


print(f"Zastosowanie map() {list(map(zmien, lista))}")


print(f"Zastosowanie map() {list(map(lambda x: x * 2, lista))}")
print(f"Zastosowanie map() {list(map(lambda x: x * 4, lista))}")
print(f"Zastosowanie map() {list(map(lambda x: x * 5, lista))}")
print(f"Zastosowanie map() {list(map(lambda x: x * 12, lista))}")
print(f"Zastosowanie map() {list(map(lambda x: x / 2, lista))}")


print(f"Zastosowanie filter {list(filter(lambda x: x < 3, lista))}")
print(f"Zastosowanie filter {list(filter(lambda x: x > 20, lista))}")
print(f"Zastosowanie filter {list(filter(lambda x: x > 20 and x < 200, lista))}")
print(f"Zastosowanie filter {list(filter(lambda x: 20 < x < 200, lista))}")