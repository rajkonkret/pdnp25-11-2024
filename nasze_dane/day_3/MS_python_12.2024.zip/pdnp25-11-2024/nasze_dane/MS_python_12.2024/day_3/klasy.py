# klasy

class Human:
    """
    Klasa Human w pythonie
    """

    imie = ""
    wiek = None
    plec = "k"


print(Human.__doc__)
cz1 = Human()
print(cz1)

print(cz1.imie)
print(cz1.wiek)
print(cz1.plec)

cz1.imie = "Anna"
cz1.wiek = 27

print(cz1.imie)  # Anna
print(cz1.wiek)  # 27
print(cz1.plec)  # k

cz2 = Human()
cz2.imie = "Radek"
cz2.wiek = 45
cz2.plec = "m"

print(cz2.imie)
print(cz2.wiek)
print(cz2.plec)
