# kolekcje
#  mogą przechowywać wilele elementów, różnego typu na raz
# Lista - przechowuje dowolna ilośc elelmentów, róznego rodzaju na raz
# zachowuje kolejność przy dodawaniu elementów

# pusta lista
lista = []
print(lista)  # []
print(type(lista))  # <class 'list'>

pusta_lista = list()
print(pusta_lista)  # []
print(type(pusta_lista))  # <class 'list'>