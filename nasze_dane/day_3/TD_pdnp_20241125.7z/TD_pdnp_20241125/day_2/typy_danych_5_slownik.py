# słownik - dane typu para -> klucz, wartość
# {"user" : "Radek", "wiek" :78}
# {"klucz" : "wartość"}
# {"FirstName" : "Radek", "LastName" :78}
# klucze nie moga sie powtarzac

# pusty złownik
dictionary = dict()
print(dictionary) # {}

dictionary1 = dict()
print(dictionary1) # {}
print(type(dictionary1)) # <class 'dict'>

# dodawanie elementów do słownika
dictionary['imie'] = "Radek" # {'imie': 'Radek'}
print(dictionary)

dictionary['wiek'] = "45"
print(dictionary) # {'imie': 'Radek', 'wiek': '45'}

# nadpisanie elementu
dictionary['imie'] = "Tomek" #
print(dictionary) # {'imie': 'Tomek', 'wiek': '45'}

# klucze, wartości, pary
print(dictionary.keys()) # dict_keys(['imie', 'wiek']) - klucze
print(dictionary.values()) # dict_values(['Tomek', '45']) - wartości
print(dictionary.items()) # dict_items([('imie', 'Tomek'), ('wiek', '45')]) - pary

# wypisanie elementu ze słownika
print(dictionary['imie']) # Tomek
print(dictionary['wiek']) # 45

# gdy nie ma klucza
# print(dictionary['imiei']) # KeyError: 'imiei'
# print(dictionary.get['imiei']) # TypeError: 'builtin_function_or_method' object is not subscriptable


dictionary.update({"date": "2024-12-12"}) # {'imie': 'Tomek', 'wiek': '45', 'date': '2024-12-12'}
print(dictionary)

dict_small = {"x": 2}
dict_small.update([('y',3), ("z", 7)])
print(dict_small) # {'x': 2, 'y': 3, 'z': 7}

# input - pobiera dane od użytkownika # zwraca zawsze stringa

# tekst = input("Podaj imie")
# print(tekst) # Podaj imie # Podaj imie Radek # Radek / Podaj imieStefan #Stefan

# napisać aplikacje kalkulator
# pobrac liczby -  2 x input
# wypisać wynik dodawania

# a = input("liczba1")
# b = input("liczba2")
# print(float(a) * float(b))

# napisać aplikację pol-ang
# słownik ze słówkami i tłumaczeniami
# pobrać od użytkownika o co pyta -> input
# wyświetlic tłumaczenie -> wartość klucza

slownik = {"kot": "cat", "pies": "dog", "słońce": "sun"}
slowo = input("podaj slowo do tlumaczenia")
tlumaczenie=slownik.get(slowo)
print(tlumaczenie)

# niemieckie ss ()
# print(slownik[tlumaczenie.casefold()])














