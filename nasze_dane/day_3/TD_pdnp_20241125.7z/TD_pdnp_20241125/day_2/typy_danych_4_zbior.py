# zbiór (set) - przechowuje unikalne wartości
# nie zachowuje kolejności pzry dodawaniu elementow
# nie ma indeksu

lista = [44,55,66,777,33,22,11,33,11]
zbior = set(lista)
print(type(zbior)) # <class 'set'>
print(zbior) # {33, 66, 777, 11, 44, 22, 55}

# tworzenie pustego zbioru
zb2 = set()
print(zb2) # set()
# dodanie elementu do zbioru
zbior.add(33)
zbior.add(33)
zbior.add(33)
zbior.add(33)
zbior.add(18)
zbior.add(18)
zbior.add(24)
print(zbior) # {33, 66, 777, 11, 44, 18, 22, 55, 24}

# usunięcie elementu ze zbioru
zbior.remove(55)
print(zbior) # {33, 66, 777, 11, 44, 18, 22, 24}

# pop() - usuwał i wyświetlał po indeksie
print(zbior.pop()) # usunął pierwszy - 33

zbior_copy = zbior.copy()
print(zbior)        # {66, 777, 11, 44, 18, 22, 24}
print(zbior_copy)   # {66, 18, 22, 24, 777, 11, 44}
print(id(zbior))
print(id(zbior_copy))
# 2138180404384
# 2138180688064

zbior2 = {667,11,44,18,52,62,999,999,12.34}
print(zbior2) # {999, 11, 44, 12.34, 18, 52, 667, 62}
print(type(zbior2)) # <class 'set'>
# suma zbiorów - nowy zbior
print(zbior | zbior2) # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 667, 62}
print(zbior.union(zbior2)) # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 667, 62}
# część wspólna
print(zbior & zbior2) # {18, 11, 44}
print(zbior.intersection(zbior2)) # {18, 11, 44}

# różnica
print(zbior - zbior2)           # {24, 777, 66, 22}
print(zbior.difference(zbior2)) # {24, 777, 66, 22}
print(zbior2.difference(zbior)) # {999, 12.34, 52, 667, 62}

# modyfikuje zbiór bazowy
zbior.update(zbior2)
print(zbior) # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 667, 62}

# sprawdzamy cy jest taka wartość
print(999 in zbior) # True

print(sorted(zbior))    # [11, 12.34, 18, 22, 24, 44, 52, 62, 66, 667, 777, 999] -  zwraca listę, nie zmienia zbioru
print(zbior)            # {66, 999, 777, 11, 44, 12.34, 18, 52, 22, 24, 667, 62}







