import sys

wiek = 47
rok = 2024
temp = 36.6

print(temp) # 36.6
print(type(temp)) # <class 'float'>


print(wiek + rok)
print(wiek - rok)
print(wiek * rok)
print(wiek / rok)

print(rok // wiek) # część całkowia dzielenia wynik 43
print(rok % wiek) # reszta z dzielenia (modulo) wynik 3

print(10 % 3) # reszta z dzielenia 10 na 3, bo 3 całe i reszta 1
print(wiek ** rok) # potęgowanie

# len() - długośc zbioru
print(len(str(wiek ** rok))) # wartość 3385
# print(len(str(wiek ** rok ** 2))) - przekroczyliśmy 4300 (ValueError: Exceeds the limit (4300 digits) for integer string conversion; use sys.set_int_max_str_digits() to increase the limit)

print(1/3) # wartość 0.3333333333333333

print(54 - 5 * 43 + 8/2 + 8/2)
print(54 - 5 * 43 + (8/2 + 8)/2)
# liczby float maja błąd zaokrąglenia
print(0.2 + 0.8) # 1.0
print(0.2 + 0.7) # 0.8999999999999999
print(0.1 + 0.2) # 0.30000000000000004

# typ decimal - pozwala ominąć problem zaokrągleń.

print(sys.float_info)
# sys.float_info(max=1.7976931348623157e+308
# , max_exp=1024
# , max_10_exp=308
# , min=2.2250738585072014e-308
# , min_exp=-1021, min_10_exp=-307
# , dig=15
# , mant_dig=53
# , epsilon=2.220446049250313e-16
# , radix=2
# , rounds=1)

print(f"sprawdzenie zmiennej {temp} {wiek}")
print("""
{wiek}
    {temp}""")

# typ logiczny
# prawda fałsz
# True
# False
czy_znasz_python = True
print(czy_znasz_python)
print(type(czy_znasz_python)) # <class 'bool'>
print(int(True))
print(int(False))
print(bool(1))
print(bool(0))
print(bool(100)) # wszystko co percrpcyjnie uważamy za zero będzie False
print(bool(-10))
print(bool(0))
print(bool(""))
print(bool(None)) # stan nieokreślony -> NULL

# działania logiczne

# and -> i
# or -> lub
# not - negacja

a = 8
b = 6
print(f"Porównanie {a} > {b} = {a > b}")
print(f"Porównanie {a} < {b} = {a < b}")
print(f"Porównanie {a} >= {b} = {a >= b}")
print(f"Porównanie {a} <= {b} = {a <= b}")
print(f"Porównanie {a} == {b} = {a == b}")
print(f"Porównanie {a} != {b} = {a != b}")
