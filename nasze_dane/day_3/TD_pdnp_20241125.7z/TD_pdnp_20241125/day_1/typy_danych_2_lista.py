# kolekcje
#  - mogą przechowywać wiele elementów
# # przechowuje dowolmą ilośc elementów
# # - zachowuje kolejność elementów
lista = []
print(lista)
print(type(lista))

pusta_lista = list()
print(pusta_lista) #[]
print(type(pusta_lista)) # <class 'list'>

# dodawanie elementów do listy
lista.append("Darek")
lista.append("Zocha")
lista.append("Stefan")
lista.append("Zygmunt")
lista.append("Zenek")
lista.append("Alfons")
lista.append("Fakir z Kutna")
lista.append("Hermenegilda")

print(lista)
# możemy wypisać po numerze indeksu

#ctrl alt l - formatowanie zgodne z pep8

# ['Darek', 'Zocha', 'Stefan', 'Zygmunt', 'Alfons', 'Fakir z Kutna']
#       0       1       2           3           4           5
#       -6      -5     -4           -3          -2          -1

print(lista[0])
print(lista[2])
print(lista[4])
# print(len(lista))
# print(lista[7]) #IndexError: list index out of range - nie ma elementu z indeksem 7

print(lista[len(lista) - 1]) # Fakir z Kutna
print(lista[-1])
print(lista[-2])
print(lista[-3])

# wyświetalnie fragmentu listy (slicowanie)

print(lista[0:3]) # ['Darek', 'Zocha', 'Stefan'] indeksy 0 1 2
print(lista[:3]) # ['Darek', 'Zocha', 'Stefan'] indeksy 0 1 2
print(lista[2:]) # ['Stefan', 'Zygmunt', 'Alfons', 'Fakir z Kutna'] indeksy 2 3 4 5
print(lista[2:5]) # ['Stefan', 'Zygmunt', 'Alfons']  indeksy 2 3 4
print(lista[2:]) # ['Stefan', 'Zygmunt', 'Alfons', 'Fakir z Kutna']
print(lista[2:5]) # ['Stefan', 'Zygmunt', 'Alfons']
print(lista[2:10]) # ['Stefan', 'Zygmunt', 'Alfons', 'Fakir z Kutna']
print(lista[10:20]) # [] -> pusta lista
print(lista[2:2]) # [] -> pusta lista
print(lista[2:3]) # [] ->['Stefan']
print(lista[:]) # ['Darek', 'Zocha', 'Stefan', 'Zygmunt', 'Alfons', 'Fakir z Kutna']-> wyświetli wszystko
print(lista[-2:0]) # [5:0] - na osi nie da się przejść -2 do 0 w lewo i odwrotnie 5 do 0 w prawo
print(lista[0:-2]) # ['Darek', 'Zocha', 'Stefan', 'Zygmunt']
print(lista[-6:-2]) # ['Darek', 'Zocha', 'Stefan', 'Zygmunt']

# czasem trzeba wygenerować listę złożoną z liczb (mamy mechanizm generowania)
lista_15 = list(range(15)) # 0 do 14
print(lista_15) # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
print(lista_15[0:15:2]) # [start:stop:krok] co druga
print(list(range(0, 15, 2))) # generujemy listę co drugą (start,stop,krok) co druga
print(lista_15[-10]) # [5]

# nadpisanie elementu
lista[3] = "Mikołaj"
print(lista)

# dopisanie do listy we wskazanym indeksie
lista.insert(1, "Marek")
print(lista) # ['Darek', 'Marek', 'Zocha', 'Stefan', 'Mikołaj', 'Alfons', 'Fakir z Kutna', 'Hermenegilda']

# sprawdzenie na którym jest dany element
print(lista.index("Mikołaj")) # index = 4 (case sensitive - wielkość liter ma znaczenie)

# usunięcie elementu z listy
lista.append(("Zenek"))
print(lista)
lista.remove(("Zenek")) # usuwa pierwsze wystąpienie elementu licząc od lewej strony
print(lista)

# usunięcie elementu z listy po indeksie
print(lista.pop(5)) # metoda pop usuwa i zwraca co usunęła Alfons

# usuwanie po ujemnym indeksie Alfons
print(lista.pop(-2)) # metoda pop usuwa i zwraca co usunęła Hermenegilda
print(lista.pop()) # ostatni element Zenek
print(lista) # ['Darek', 'Marek', 'Zocha', 'Stefan', 'Mikołaj', 'Fakir z Kutna']

a = 1
b = 3
print(a,b)
a = b       # do a wpisano wartość b, a jest kopią b
print(a,b)  # 3 3

b = 7
print(f"{a=}, {b=}") # wstrzykiwanie wertości zmiennej do tekstu # a=3, b=7

lista_2 = lista # kopia adresu w pamięci, referencji
lista.clear() # czyszczenie elementów listy
print(lista) # []
print(lista_2) # []
lista_copy = lista.copy()
print(id(lista))        # 2883465748672
print(id(lista_2))      # 2883465748672
print(id(lista_copy))   # 2883467869632


liczby = [54, 99,34, 22, 12, 12.34,687]
print(liczby) # [54, 99, 34, 22, 12, 12.34, 687]
print(type(liczby)) # <class 'list'>

liczby.sort()
print(liczby)

# liczby = [54, 99,34, 22, 12, 12.34,687,"A"]
# liczby.sort() # TypeError: '<' not supported between instances of 'str' and 'int'
print(liczby)

lista_litery = ["a", "b", "c", "z"]
lista_litery.sort() # sortowanie listy
print(lista_litery)

lista_litery.reverse() # odwrócenie listy
print(lista_litery)

# sortowanie z odwróceniem
lista_litery.sort(reverse=True)
print(lista_litery) # ['z', 'c', 'b', 'a']
print(lista_litery[::-1]) # wyświetlenie listy w odwrotnej kolejności (-1)

liczby[3] = 666
print(liczby[0:3])
print(liczby[-2])
print(liczby)

print(liczby.pop(2))
liczby.remove(54)
print(liczby)

del liczby
# print(liczby) NameError: name 'liczby' is not defined

# rozpakowanie sekwencji
tekst = "Pyt hon"
lista1 = list(tekst)
print(lista1) # ['P', 'y', 't', ' ', 'h', 'o', 'n']

lista2 = [tekst]
print(lista2) # ['Pyt hon']

# zamiana na krotkę (tuple)
krotka = tuple(lista_litery)
print(krotka) # ('z', 'c', 'b', 'a')
print(type(krotka)) # <class 'tuple'>

