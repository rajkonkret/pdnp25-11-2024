user = "Datek" # str
wiek = 39 #int
wersja = 3.91 # float
print(type(wersja)) # <class 'float'>
liczba = 56955885256525252
print("Witaj %s, masz teraz %d lat" % (user, wiek))
print("Witaj %(user)s, masz teraz %(user)s lat" % {"user": user})

print("Używamy wersji %i" % 3)
print("Używamy wersji %f" % 3)
print("Używamy wersji %.2f" % 3.9)
print("Używamy wersji %.1f" % 3.9)
print("Używamy wersji %.0f" % 3.9)
print("Używamy wersji %.f" % 3.9)
# zaokrągla do wyświet;ania

wynik = 3.8765
print("Wynik = %.2f" % wynik)

print(f"uzywamy wersji {wersja}")
print(f"uzywamy wersji {wersja:.1f}")
print(f"uzywamy wersji {wersja:.2f}")
print(f"uzywamy wersji {wersja:.0f}")
#print(f"uzywamy wersji {wersja:.f}") # ValueError: Format specifier missing precision

print(f"{user:>10}") # "     Datek" - wyrównało do prawej 10 znaków przed
print(f"{user:<15}") # "Datek          " - wyrównało do lewej 15 znaków po
print(f"{user:^20}") # "       Datek        " - wyśrodkowało 20znaków

#zapis liczby w formacie dogodnym do czytania

print(liczba) #
print(f"Nasza duża liczba {liczba:,}") # Nasza duża liczba 56,955,885,256,525,252
print(f"Nasza duża liczba {liczba:_}") # Nasza duża liczba 56_955_885_256_525_252
print(f"Nasza duża liczba {liczba:_}".replace("_",".")) # Nasza duża liczba 56.955.885.256.525.252
print(f"Nasza duża liczba {liczba:_}".replace("_"," ")) # Nasza duża liczba 56 955 885 256 525 252


# liczba_2 = 1500000000000
liczba_2 = 150_000_000_000
print(liczba_2) # 150000000000
print(type(liczba_2)) # <class 'int'>

