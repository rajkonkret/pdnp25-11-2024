# wyjątki - błędy pojawiające się w probramowaniu

# print(5/0)
# Traceback (most recent call last):
#   File "C:\Users\CSComarch\PycharmProjects\pdnp25-11-2024\nasze_dane\TD_pdnp_20241125\day_3\wyjatki.py", line 2, in <module>
#     print(5/0)
#           ~^~
# ZeroDivisionError: division by zero
# print("Dalsza czesc programu")

try:
    # print(5/0)
    # print("A" + 9)
    # print(int("A"))
    #raise KeyError("Brak klucza")
    wynik = 90 / 34
except ZeroDivisionError:
    print("nie dziel przez 0")
except TypeError:
    print("błąd typu")
except ValueError:
    print("błąd wartosci")
except Exception as e:
    print("bład: ", e)
else: # tylko gdy nie ma błędu
    print("wynik", wynik)
finally:
    print("wykona się zawsze")
# wynik 2.6470588235294117
# wykona się zawsze

