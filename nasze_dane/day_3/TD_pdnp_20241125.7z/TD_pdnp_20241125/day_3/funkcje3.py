# funkcja lambda
# skrócony zapis funkcji
# zawsze zwraca wynik (return)
# funkcja anonimowa

def odejmij(a, b):
    return a - b


print(odejmij(45, 90))  # -45
# alternatywa dla powyzsze funkcji
odejmij2 = lambda a, b: a - b

print(odejmij2(45, 78))  # -33

wiek = lambda x: "dziecko" if x < 10 else ("nastolatek" if x < 18 else "dorosły")
print(wiek(9))  # dziecko
print(wiek(10))  # nastolatek
print(wiek(17))  # nastolatek
print(wiek(18))  # dorosły
print(wiek(25))  # dorosły

# przemnozyć *2 i zapisać do nowej listy (pętka, pętla z funkcją, pętla jednolinijkowa - contrahention)
lista = [1, 2, 3, 10, 20, 30, 100, 200, 500]
lista_wyn = []

print([i * 2 for i in lista])


def zmien(x):
    return x * 2


for i in lista:
    lista_wyn.append(zmien(i))
print(lista_wyn)  # [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# map() - mapowanie danych - zmiana danych wg zadanej funkcji

print(f" zastosowanie map() {list(map(zmien, lista))}")  # zastosowanie map() [2, 4, 6, 20, 40, 60, 200, 400, 1000]

# lambda jako funkcja anonimowa anonimowa oznacza wykonanie w miejscu deklaracji

print(f" zastosowanie map() z funkcją anonimowa lambda {list(map(lambda x: x * 2, lista))}")
print(f" zastosowanie map() z funkcją anonimowa lambda {list(map(lambda x: x * 4, lista))}")
print(f" zastosowanie map() z funkcją anonimowa lambda {list(map(lambda x: x * 5, lista))}")
print(f" zastosowanie map() z funkcją anonimowa lambda {list(map(lambda x: x * 12, lista))}")
print(f" zastosowanie map() z funkcją anonimowa lambda {list(map(lambda x: x / 2, lista))}")

# zastosowanie map() z funkcją anonimowa lambda [2, 4, 6, 20, 40, 60, 200, 400, 1000]
# zastosowanie map() z funkcją anonimowa lambda[4, 8, 12, 40, 80, 120, 400, 800, 2000]
# zastosowanie map() z funkcją anonimowa lambda[5, 10, 15, 50, 100, 150, 500, 1000, 2500]
# zastosowanie map() z funkcją anonimowa lambda[12, 24, 36, 120, 240, 360, 1200, 2400, 6000]
# zastosowanie map() z funkcją anonimowa lambda[0.5, 1.0, 1.5, 5.0, 10.0, 15.0, 50.0, 100.0, 250.0]

# filtrowanie danych - zwraca tylko dane spełniające warunek
# filter() - zwraca elementy spełniającewarunek
# funkcje wyższego rzędu
print(f" zastosowanie filter {list(filter(lambda x: x < 3, lista))}")
print(f" zastosowanie filter {list(filter(lambda x: x > 20, lista))}")
print(f" zastosowanie filter {list(filter(lambda x: x > 20 and x < 200, lista))}")
print(f" zastosowanie filter {list(filter(lambda x: 20 < x < 200, lista))}")
# zastosowanie filter[1, 2]
# zastosowanie filter[30, 100, 200, 500]
# zastosowanie filter[30, 100]
# zastosowanie filter [30, 100]


