# pętle - mozliwość wykonania tegosamego kodu wielokrotnie
# for - pętgla iteracyjna
import random # do działan na liczbach pseudolosowych
for i in range(5): # generuje liczby z zakresu 0-4
    print(i)

# 0
# 1
# 2
# 3
# 4

for i in range(1000):
    pass # nic nie robi, ale w pętli coś musi być

for _ in range(10): # zmienną _ stosuje się jeśli nie potzrebujemy uzyć wartości zmiennej  (tzw: niemazmienna)
    print("To jest petla")
    # print(_)


print(random.randint(1,100)) # od 1 do 100
print(random.randrange(1,100)) # 1 do 99
print(random.randrange(6)) # od 0 do 5
print(random.random()) # 0.6120662783780852 od 0 do 0,9999999

# jak wylosować liczbę z tej listy ( randrange  i -1
lista = [67,45,32,68,89,90,42]
print(random.choice(lista)) # 32

lista_kule = list(range(1,50))
print(lista_kule)

lista_wylosowana = []
for _  in range(6):
    wyn = random.choice(lista_kule)
    lista_kule.remove(wyn)
    lista_wylosowana.append(wyn)

print(lista_wylosowana) # [10, 21, 27, 25, 12, 45]
print(random.choices(lista_kule, k=6)) # [18, 25, 16, 24, 22, 43] losuje z powtórzeniami - k ile losuje liczb
print(random.sample(lista_kule, k=6)) # [7, 31, 13, 18, 22, 9] losuje unikalne wartości - k ile losuje liczb

for i in range(10):
    if i % 2 == 0:
        print(i,"parzysta")

# 0 parzysta
# 2 parzysta
# 4 parzysta
# 6 parzysta
# 8 parzysta

# list comprehensions
lista = [j for j in range(10) if j % 2 == 0] # do listy wrzuc liczby które spełniają
print(lista) # [0, 2, 4, 6, 8]

# pętla po kolekcji
for c in lista_wylosowana:
    if c > 10:
        print("większe od 10")
    else:
        print("mniejsze lub równe od 10")

# większe od 10
# większe od 10
# mniejsze lub równe od 10
# większe od 10
# większe od 10
# większe od 10

# iteracja po słownikach

dictionary = {'imie':"Radek",'nazwisko': "Kowalski"}
for i in dictionary:
    print(i)
# imie
# nazwisko

for k in dictionary.keys():
    print(k)
# imie
# nazwisko

for v in dictionary.values():
    print(v)
# Radek
# Kowalski

for i in dictionary.items():
    print(i)
# ('imie', 'Radek')
# ('nazwisko', 'Kowalski') # krotki

# jak z krotek wyciągnąć (rozpakowanie krotgki)

for k,v in dictionary.items():
    print(k, "=>", v)
# imie => Radek
# nazwisko => Kowalski



