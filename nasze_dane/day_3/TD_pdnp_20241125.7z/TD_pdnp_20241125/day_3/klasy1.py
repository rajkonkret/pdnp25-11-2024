# programowanie obiektowe z uzyciem klas jest trocheinny odejściem do programowania
# klasa - szablon, przepis wg. którego tworzymy (element architektoniczny)
# cechy i funkcje
# obiekt - zbydowany wg. przepisu
# klasa musi być najpierw zadeklarowana
# budowanie obiektu klasy uruchamia metode  inicjalizującą
# paradygmaty - hermetyzacja, dziedziczenie, polimorfizm, abstrakcja
# nazwa klasy wg. PEP8 piszemy z dużej litery


class Human:
    """
    Klasa Human w pythonie
    """
    imie = ""
    wiek = None
    plec = "k"


print(Human.__doc__)  # klasa Human w pythonie (dokumentacja)
cz1 = Human()  # tworzenie obiektu klasy
print(cz1)  # <__main__.Human object at 0x0000024505756900>
print(cz1.imie)  #
print(cz1.wiek)  # None
print(cz1.plec)  # k

cz1.imie = "Joanna"
cz1.wiek = 27

print(cz1.imie)  # Joanna
print(cz1.wiek)  # 27
print(cz1.plec)  # k

cz2 = Human()
cz2.imie = "Stefan"
cz2.wiek = 45
cz2.plec = "m"

print(cz2.imie)  # Stefan
print(cz2.wiek)  # 45
print(cz2.plec)  # m
