# działanie z plikami
# narzędzie nazywa się file handler
#context manager
# with


with open('test.log', 'w') as fh:
    fh.write('Powitanie \n')

with open('test.log', 'x') as f:
    fh.write('Test.log \n')