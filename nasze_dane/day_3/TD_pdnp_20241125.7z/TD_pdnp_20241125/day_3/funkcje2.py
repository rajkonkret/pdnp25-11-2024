a = 10
b = 10


def dodaj():
    a = 7
    b = 8
    print(a + b)


def dodaj2():
    global a # jest też nonlocal - podobne, ale różni się od global
    a = 9 # użyje globalne a, zmieniamy jego wartość (zmieni na 9)
    b = 89
    print(a + b)

def dodaj3():
    print(a+b)

print(f"wartość a z góry {a=} {b=} (globalne)")  # wartość a z góry a=10 b=10 (globalne)
dodaj()  # 15
print(f"wartość a z góry {a=} {b=} (globalne)")  # wartość a z góry a=10 b=10 (globalne)
dodaj2()  #98
print(f"wartość a z góry {a=} {b=} (globalne)")  # wartość a z góry a=9 b=10 (globalne)
dodaj3()  #19
print(f"wartość a z góry {a=} {b=} (globalne)")  # wartość a z góry a=9 b=10 (globalne)
