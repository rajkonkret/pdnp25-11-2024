# od python 3.10 jest alternatywa dla if
# match case

lista = []
lang = input("podaj znany Ci język programpwania")
match lang.casefold()().strip():
    case "python":
        lista.append("znam pythona")
    case "java":
        lista.append(("java"))
    case _: # odpowiednik else
        print("Nie znam takiego jezyka")

print(lista)
# podaj znany Ci język programpwania