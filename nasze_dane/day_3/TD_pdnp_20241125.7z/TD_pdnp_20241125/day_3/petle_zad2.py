# petla while - pętla sterowana warunkiem

#petla nieskończona
# while True:
#     print("komunikat !!!")

#
# licznik = 0
# while True:
#     licznik += 1 # licznik = licznik + 1
#     print("komunikat 2 !!!")
#     if licznik > 10:
#         break # przerwanie petli
# print(licznik)
#
# licznik = 0
# while licznik < 10:
#     licznik += 1
#     print("komunikat 3 !!!")
# # sprawdza, czy każdy znak jest liczba
# lista = []
# lista_int = []
# while True:
#     wej = input("podaj liczbę")
#     if not wej.isnumeric(): # A string is numeric if all characters in the string are numeric
#         break
#     lista.append(wej)
#     lista_int.append(int(wej))
#
# print(lista)

my_list = [1, 5, 2, 3, 5, 4, 5, 6, 5] # ctrl alt l - pep8
print(5 in my_list)
while 5 in my_list:
    my_list.remove(5)
print(my_list)

# True
# [1, 2, 3, 4, 6]

