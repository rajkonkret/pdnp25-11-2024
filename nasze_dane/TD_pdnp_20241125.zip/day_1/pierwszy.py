# komentarz
# PEP8 - zasady formatowania kodu
import sys

print("nazywam się Bond, James Bond")  #wypisz/wydrukuj
print("nazywam się Bond, James Bond")
print("nazywam się Bond, James Bond")
print("nazywam się Bond, James Bond")
#ctrl d - powielanie linii

# ctrl / - komentowanie

print(type("Radek"))
print("39")
print(39)
print(type(39))
print(39+39)
print("39"+"39")
print(int("39")+int("39"))
print("Darek: "+str(39))
print(5*"4")
print("160" * 35)

# zmienne - pudełko na dane
# nazwy zmiennych z małej litery
# snake_casy
# nazwa zmiennej powinna wskazywać co przechowuje

# typowanie dynamiczne - można zmieniać typy jakie przechowuje zmienna
liczba = 39
print(type(liczba))
print(liczba)

liczba = "Radek"
print(type(liczba))
print(liczba)

name: str = "Radek"
print(name)
print(type(name))

name= 90
print(name)
print(type(name))

print(sys.int_info)

# w puthon3 mówi się, że wszystgko jest obiektem
from itertools import count

tekst = "Witaj Świecie"
print(tekst)
print(type(tekst))
# Witaj Świecie
# <class 'str'>

# teksty są niemutowalne
# wszystko jest obiektem
# """ Return a copy of the string converted to uppercase. """
tekst.upper()  # nie zmienia orginalnego
print(tekst.upper())  # WITAJ ŚWIECIE
print(tekst)  # Witaj Świecie
tekst_upper = tekst.upper()
print(tekst_upper)  # WITAJ ŚWIECIE

# zamienic na małe litery
print(tekst.lower())  # witaj świecie
tekst_lower = tekst.lower()
print(tekst_lower)  # witaj świecie

# Witaj Świecie
# 0123456789012...

print(tekst.count("i"))  # 3 występuje 3 razy
# start 0, stop 4 niewłacznie!
print(tekst.count("j", 0, 4))  # indeksy 0123 -> występuje 0 razy

# testowanie tabnine
print(tekst.find("j"))  # 4
print(tekst.find("j", 7))  # -1, nie ma takiego znaku
print(tekst.find("j", 13))  # -1, nie ma takiego znaku

tekst_zamiana = "Witaj dobry Świecie"
print(tekst_zamiana.replace("dobry", ""))  # "Witaj  Świecie"
print(tekst_zamiana.replace("dobry ", ""))  # "Witaj Świecie"

# strip() - usunie białe znaki, spacje z początku i końća tekstu
print(tekst.removeprefix("Witaj"))  # " Świecie"
print(tekst.removeprefix("Witaj").strip())  # "Świecie"
print(tekst.removesuffix("Świecie"))  # "Witaj "
print(tekst.removesuffix("Świecie").strip())  # "Witaj"
print(tekst.removesuffix("Witaj").strip())  # "Witaj Świecie"

print(tekst[4]) # indeks numer 4
# kodowanie
encode_s = tekst.encode('utf-8')
print(encode_s) # b'Witaj \xc5\x9awiecie' - zamieniony na ciąg bajtowy \x - liczba w systemie szesnastkowym
# encode_s = tekst.encode('ISO8859-2')
# print(encode_s)

#odkodowanie

print(encode_s.decode('UTF8'))
# tekst format
# f - fsrting
imie = "Radek"
tekst_format = f"Mam na imię {imie} i lubię Python-a"
print(tekst_format)
# łamanie tekstu
tekst_format = f"\tMam na imię {imie}\n i lubię Python-a.\b"
print(tekst_format)

# starszy sposób wstawiania zmiennych
starszy = "Witaj %s!" # s% - string
print(starszy % imie) # Witaj Radek! pod %s zostanie podstawiona wartość zmiennej imie
print("Witaj {}".format(imie)) # Witaj Radek
print("Witaj", imie) # Witaj Radek - przy takim zapisie automatycznie dodaje spację
print("""
Tekst
    wielolinijkowy
""")
# Tekst
#     wielolinijkowy


